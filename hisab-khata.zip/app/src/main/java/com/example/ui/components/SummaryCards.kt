package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.InfoBlueContainer
import com.example.ui.theme.NegativeRed
import com.example.ui.theme.NegativeRedContainer
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.PositiveGreenContainer
import com.example.ui.theme.TertiaryAmber
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeContainer

@Composable
fun DashboardSummarySection(
    currencySymbol: String,
    totalReceivable: Double,
    totalPayable: Double,
    todaySales: Double,
    todayPurchases: Double,
    todayExpenses: Double,
    totalNetProfit: Double,
    cashInHand: Double,
    totalTransactionsCount: Int,
    isBengali: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Hero Balance / Cash Flow banner
        HeroCashBanner(
            currencySymbol = currencySymbol,
            cashInHand = cashInHand,
            totalNetProfit = totalNetProfit,
            isBengali = isBengali
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 2x2 Metric Cards Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                modifier = Modifier.weight(1f),
                title = if (isBengali) "মোট পাওনা" else "Total Receivable",
                amount = totalReceivable,
                currencySymbol = currencySymbol,
                icon = Icons.AutoMirrored.Filled.TrendingUp,
                accentColor = PositiveGreen,
                containerColor = PositiveGreenContainer,
                isBengali = isBengali,
                subtitle = if (isBengali) "কাস্টমারদের কাছে বাকি" else "Due from customers"
            )
            MetricCard(
                modifier = Modifier.weight(1f),
                title = if (isBengali) "মোট দেনা" else "Total Payable",
                amount = totalPayable,
                currencySymbol = currencySymbol,
                icon = Icons.AutoMirrored.Filled.TrendingDown,
                accentColor = NegativeRed,
                containerColor = NegativeRedContainer,
                isBengali = isBengali,
                subtitle = if (isBengali) "মহাজনদের বাকি" else "Due to suppliers"
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SmallMetricCard(
                modifier = Modifier.weight(1f),
                title = if (isBengali) "আজকের বিক্রয়" else "Today's Sales",
                amount = todaySales,
                currencySymbol = currencySymbol,
                icon = Icons.Default.Sell,
                color = InfoBlue,
                isBengali = isBengali
            )
            SmallMetricCard(
                modifier = Modifier.weight(1f),
                title = if (isBengali) "আজকের ক্রয়" else "Today's Purchase",
                amount = todayPurchases,
                currencySymbol = currencySymbol,
                icon = Icons.Default.ShoppingCart,
                color = TertiaryAmber,
                isBengali = isBengali
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SmallMetricCard(
                modifier = Modifier.weight(1f),
                title = if (isBengali) "আজকের খরচ" else "Today's Expense",
                amount = todayExpenses,
                currencySymbol = currencySymbol,
                icon = Icons.Default.ReceiptLong,
                color = WarningOrange,
                isBengali = isBengali
            )
            SmallMetricCard(
                modifier = Modifier.weight(1f),
                title = if (isBengali) "মোট লেনদেন" else "Transactions",
                amount = totalTransactionsCount.toDouble(),
                currencySymbol = "",
                icon = Icons.Default.Receipt,
                color = EmeraldPrimary,
                isBengali = isBengali,
                isCount = true
            )
        }
    }
}

@Composable
fun HeroCashBanner(
    currencySymbol: String,
    cashInHand: Double,
    totalNetProfit: Double,
    isBengali: Boolean
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF4F46E5), // Indigo 600
                        Color(0xFF3730A3)  // Indigo 800
                    )
                ),
                shape = RoundedCornerShape(24.dp)
            )
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isBengali) "হাতে নগদ (ক্যাশ ব্যালেন্স)" else "Cash in Hand",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White.copy(alpha = 0.85f),
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = NumberFormatHelper.formatMoney(cashInHand, currencySymbol, isBengali),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 26.sp
                        )
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.18f),
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (totalNetProfit >= 0) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown,
                            contentDescription = null,
                            tint = if (totalNetProfit >= 0) Color(0xFF86EFAC) else Color(0xFFFCA5A5),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBengali) "মোট নিট লাভ/ক্ষতি:" else "Net Profit/Loss:",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        )
                    }
                    Text(
                        text = (if (totalNetProfit >= 0) "+ " else "- ") + NumberFormatHelper.formatMoney(
                            kotlin.math.abs(totalNetProfit),
                            currencySymbol,
                            isBengali
                        ),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (totalNetProfit >= 0) Color(0xFF86EFAC) else Color(0xFFFCA5A5)
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    modifier: Modifier = Modifier,
    title: String,
    amount: Double,
    currencySymbol: String,
    icon: ImageVector,
    accentColor: Color,
    containerColor: Color,
    isBengali: Boolean,
    subtitle: String
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = containerColor,
                    modifier = Modifier.size(34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = NumberFormatHelper.formatMoney(amount, currencySymbol, isBengali),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    fontSize = 18.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
fun SmallMetricCard(
    modifier: Modifier = Modifier,
    title: String,
    amount: Double,
    currencySymbol: String,
    icon: ImageVector,
    color: Color,
    isBengali: Boolean,
    isCount: Boolean = false
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = color.copy(alpha = 0.12f),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                )
                Text(
                    text = if (isCount) {
                        NumberFormatHelper.formatNumber(amount.toInt(), isBengali) + (if (isBengali) " টি" else "")
                    } else {
                        NumberFormatHelper.formatMoney(amount, currencySymbol, isBengali)
                    },
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp
                    )
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuickActionsGrid(
    isBengali: Boolean,
    onAddPerson: () -> Unit,
    onAddDueGiven: () -> Unit,
    onAddDueTaken: () -> Unit,
    onAddReceived: () -> Unit,
    onAddExpense: () -> Unit,
    onAddSale: () -> Unit,
    onAddPurchase: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Text(
            text = if (isBengali) "দ্রুত লেনদেন (Quick Actions)" else "Quick Actions",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        )
        Spacer(modifier = Modifier.height(10.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickActionButton(
                label = if (isBengali) "+ নতুন ব্যক্তি" else "+ Add Person",
                icon = Icons.Default.PersonAdd,
                color = EmeraldPrimary,
                testTag = "quick_action_add_person",
                onClick = onAddPerson
            )
            QuickActionButton(
                label = if (isBengali) "+ দেনা যোগ" else "+ Add Payable",
                icon = Icons.Default.ArrowDownward,
                color = NegativeRed,
                testTag = "quick_action_add_due_taken",
                onClick = onAddDueTaken
            )
            QuickActionButton(
                label = if (isBengali) "+ পাওনা যোগ" else "+ Add Receivable",
                icon = Icons.Default.ArrowUpward,
                color = PositiveGreen,
                testTag = "quick_action_add_due_given",
                onClick = onAddDueGiven
            )
            QuickActionButton(
                label = if (isBengali) "+ টাকা জমা" else "+ Money In",
                icon = Icons.Default.MonetizationOn,
                color = InfoBlue,
                testTag = "quick_action_add_received",
                onClick = onAddReceived
            )
            QuickActionButton(
                label = if (isBengali) "+ খরচ যোগ" else "+ Expense",
                icon = Icons.Default.ReceiptLong,
                color = WarningOrange,
                testTag = "quick_action_add_expense",
                onClick = onAddExpense
            )
            QuickActionButton(
                label = if (isBengali) "+ বিক্রয় যোগ" else "+ Sale",
                icon = Icons.Default.Sell,
                color = PositiveGreen,
                testTag = "quick_action_add_sale",
                onClick = onAddSale
            )
            QuickActionButton(
                label = if (isBengali) "+ ক্রয় যোগ" else "+ Purchase",
                icon = Icons.Default.ShoppingCart,
                color = TertiaryAmber,
                testTag = "quick_action_add_purchase",
                onClick = onAddPurchase
            )
        }
    }
}

@Composable
fun QuickActionButton(
    label: String,
    icon: ImageVector,
    color: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.12f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = color,
                    fontSize = 12.sp
                )
            )
        }
    }
}
