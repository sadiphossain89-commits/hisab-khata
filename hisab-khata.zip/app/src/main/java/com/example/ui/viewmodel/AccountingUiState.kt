package com.example.ui.viewmodel

import com.example.data.model.BusinessEntity
import com.example.data.model.DateRangeFilter
import com.example.data.model.ExpenseEntity
import com.example.data.model.PersonEntity
import com.example.data.model.PersonWithSummary
import com.example.data.model.SalePurchaseEntity
import com.example.data.model.TransactionEntity

data class AccountingUiState(
    val isLoading: Boolean = true,
    val activeBusiness: BusinessEntity? = null,
    val allBusinesses: List<BusinessEntity> = emptyList(),
    val personsWithSummary: List<PersonWithSummary> = emptyList(),
    val allTransactions: List<TransactionEntity> = emptyList(),
    val allExpenses: List<ExpenseEntity> = emptyList(),
    val allSalePurchases: List<SalePurchaseEntity> = emptyList(),

    // Real-time calculated KPI metrics
    val totalReceivable: Double = 0.0,    // মোট পাওনা (Total Due from others)
    val totalPayable: Double = 0.0,       // মোট দেনা (Total Due to suppliers)
    val todaySales: Double = 0.0,         // আজকের বিক্রয়
    val todayPurchases: Double = 0.0,     // আজকের ক্রয়
    val todayExpenses: Double = 0.0,      // আজকের খরচ
    val totalNetProfit: Double = 0.0,     // মোট লাভ / ক্ষতি (Sales + Income - Purchases - Expenses)
    val cashInHand: Double = 0.0,         // হাতে নগদ (Cash inflow - Cash outflow)
    val totalTransactionsCount: Int = 0,

    // Navigation & View State
    val selectedTab: Int = 0, // 0: Home, 1: Accounts, 2: Spreadsheet, 3: Expenses, 4: Reports
    val selectedPersonIdForDetail: Long? = null,
    val isBengali: Boolean = true,
    val isPinLocked: Boolean = false,
    val hasPinSet: Boolean = false,

    // Search and Filters
    val searchQuery: String = "",
    val accountsFilter: String = "ALL", // ALL, DUE_RECEIVABLE, DUE_PAYABLE, ZERO_BALANCE
    val expenseCategoryFilter: String = "ALL",
    val dateFilter: DateRangeFilter = DateRangeFilter.ALL,
    val customStartDate: Long? = null,
    val customEndDate: Long? = null,

    // Spreadsheet State
    val spreadsheetSortColumn: String = "date", // "date", "name", "debit", "credit", "amount"
    val spreadsheetSortAscending: Boolean = false,
    val canUndo: Boolean = false,

    // Toast/Snackbar Message
    val userMessage: String? = null
)
