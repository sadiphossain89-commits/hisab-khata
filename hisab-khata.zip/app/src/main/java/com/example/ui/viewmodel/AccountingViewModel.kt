package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BusinessEntity
import com.example.data.model.DateRangeFilter
import com.example.data.model.ExpenseEntity
import com.example.data.model.PaymentMethod
import com.example.data.model.PersonEntity
import com.example.data.model.PersonWithSummary
import com.example.data.model.SalePurchaseEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.AccountingRepository
import com.example.data.repository.SettingsManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar

class AccountingViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = AccountingRepository(database)
    val settingsManager = SettingsManager(application)

    private val _uiState = MutableStateFlow(
        AccountingUiState(
            isBengali = settingsManager.isBengali,
            isPinLocked = settingsManager.isPinLockEnabled && settingsManager.pinCode.isNotBlank(),
            hasPinSet = settingsManager.isPinLockEnabled && settingsManager.pinCode.isNotBlank()
        )
    )
    val uiState: StateFlow<AccountingUiState> = _uiState.asStateFlow()

    private var activeDataObservationJob: Job? = null
    private val deletedTxnStack = mutableListOf<TransactionEntity>()

    init {
        initializeData()
    }

    private fun initializeData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val seededBizId = repository.seedInitialDataIfNeeded()
            var activeId = settingsManager.activeBusinessId
            if (activeId == 0L) {
                activeId = seededBizId
                settingsManager.activeBusinessId = activeId
            }

            // Observe all businesses
            repository.getAllBusinesses().collect { businesses ->
                val currentBiz = businesses.find { it.id == activeId } ?: businesses.firstOrNull()
                _uiState.update {
                    it.copy(
                        allBusinesses = businesses,
                        activeBusiness = currentBiz
                    )
                }
                if (currentBiz != null) {
                    settingsManager.activeBusinessId = currentBiz.id
                    observeBusinessData(currentBiz.id)
                }
            }
        }
    }

    fun switchBusiness(businessId: Long) {
        settingsManager.activeBusinessId = businessId
        val biz = _uiState.value.allBusinesses.find { it.id == businessId }
        _uiState.update {
            it.copy(
                activeBusiness = biz,
                selectedPersonIdForDetail = null
            )
        }
        observeBusinessData(businessId)
    }

    private fun observeBusinessData(businessId: Long) {
        activeDataObservationJob?.cancel()
        activeDataObservationJob = viewModelScope.launch {
            combine(
                repository.getPersonsByBusiness(businessId),
                repository.getTransactionsByBusiness(businessId),
                repository.getExpensesByBusiness(businessId),
                repository.getSalePurchaseItems(businessId)
            ) { persons, txns, expenses, salesPurchases ->
                calculateFullState(persons, txns, expenses, salesPurchases)
            }.collect { calculatedState ->
                _uiState.update { current ->
                    current.copy(
                        isLoading = false,
                        personsWithSummary = calculatedState.first,
                        allTransactions = calculatedState.second,
                        allExpenses = calculatedState.third,
                        allSalePurchases = calculatedState.fourth,
                        totalReceivable = calculatedState.fifth.totalReceivable,
                        totalPayable = calculatedState.fifth.totalPayable,
                        todaySales = calculatedState.fifth.todaySales,
                        todayPurchases = calculatedState.fifth.todayPurchases,
                        todayExpenses = calculatedState.fifth.todayExpenses,
                        totalNetProfit = calculatedState.fifth.totalNetProfit,
                        cashInHand = calculatedState.fifth.cashInHand,
                        totalTransactionsCount = calculatedState.second.size,
                        canUndo = deletedTxnStack.isNotEmpty()
                    )
                }
            }
        }
    }

    private data class MetricsSummary(
        val totalReceivable: Double,
        val totalPayable: Double,
        val todaySales: Double,
        val todayPurchases: Double,
        val todayExpenses: Double,
        val totalNetProfit: Double,
        val cashInHand: Double
    )

    private fun calculateFullState(
        persons: List<PersonEntity>,
        transactions: List<TransactionEntity>,
        expenses: List<ExpenseEntity>,
        salesPurchases: List<SalePurchaseEntity>
    ): Quintuple<List<PersonWithSummary>, List<TransactionEntity>, List<ExpenseEntity>, List<SalePurchaseEntity>, MetricsSummary> {
        val calendar = Calendar.getInstance()
        val startOfToday = calendar.apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val endOfToday = startOfToday + (24 * 60 * 60 * 1000L) - 1

        var todaySalesTotal = 0.0
        var todayPurchasesTotal = 0.0
        var todayExpensesTotal = 0.0
        var totalSalesAndIncome = 0.0
        var totalPurchasesAndExpenses = 0.0
        var cashIn = 0.0
        var cashOut = 0.0

        for (e in expenses) {
            if (e.date in startOfToday..endOfToday) {
                todayExpensesTotal += e.amount
            }
            totalPurchasesAndExpenses += e.amount
            if (e.paymentMethod == PaymentMethod.CASH.name) {
                cashOut += e.amount
            }
        }

        // Map transactions per person
        val txnsByPerson = transactions.filter { it.personId != null }.groupBy { it.personId!! }

        val personsWithSummaryList = persons.map { p ->
            val pTxns = txnsByPerson[p.id] ?: emptyList()
            var debitSum = if (p.openingBalanceType == "RECEIVABLE") p.openingBalance else 0.0
            var creditSum = if (p.openingBalanceType == "PAYABLE") p.openingBalance else 0.0
            var receivedSum = 0.0

            for (t in pTxns) {
                debitSum += t.debit
                creditSum += t.credit
                if (t.type == TransactionType.RECEIVED.name || t.type == TransactionType.PAID.name) {
                    receivedSum += t.amount
                }
            }
            val balance = debitSum - creditSum

            PersonWithSummary(
                person = p,
                totalDebit = debitSum,
                totalCredit = creditSum,
                totalReceived = receivedSum,
                currentBalance = balance,
                transactionCount = pTxns.size,
                lastTransactionDate = pTxns.firstOrNull()?.date
            )
        }

        var totalReceivableSum = 0.0
        var totalPayableSum = 0.0
        for (ps in personsWithSummaryList) {
            if (ps.currentBalance > 0) {
                totalReceivableSum += ps.currentBalance
            } else if (ps.currentBalance < 0) {
                totalPayableSum += kotlin.math.abs(ps.currentBalance)
            }
        }

        for (t in transactions) {
            val isToday = t.date in startOfToday..endOfToday
            when (t.type) {
                TransactionType.SALE.name -> {
                    if (isToday) todaySalesTotal += t.amount
                    totalSalesAndIncome += t.amount
                    if (t.paymentMethod == PaymentMethod.CASH.name) cashIn += t.amount
                }
                TransactionType.PURCHASE.name -> {
                    if (isToday) todayPurchasesTotal += t.amount
                    totalPurchasesAndExpenses += t.amount
                    if (t.paymentMethod == PaymentMethod.CASH.name) cashOut += t.amount
                }
                TransactionType.INCOME.name -> {
                    totalSalesAndIncome += t.amount
                    if (t.paymentMethod == PaymentMethod.CASH.name) cashIn += t.amount
                }
                TransactionType.RECEIVED.name -> {
                    if (t.paymentMethod == PaymentMethod.CASH.name) cashIn += t.amount
                }
                TransactionType.PAID.name -> {
                    if (t.paymentMethod == PaymentMethod.CASH.name) cashOut += t.amount
                }
            }
        }

        val netProfit = totalSalesAndIncome - totalPurchasesAndExpenses
        val cashInHand = (cashIn - cashOut).coerceAtLeast(0.0)

        val summary = MetricsSummary(
            totalReceivable = totalReceivableSum,
            totalPayable = totalPayableSum,
            todaySales = todaySalesTotal,
            todayPurchases = todayPurchasesTotal,
            todayExpenses = todayExpensesTotal,
            totalNetProfit = netProfit,
            cashInHand = cashInHand
        )

        return Quintuple(personsWithSummaryList, transactions, expenses, salesPurchases, summary)
    }

    // Navigation & Tab Actions
    fun selectTab(index: Int) {
        _uiState.update { it.copy(selectedTab = index) }
    }

    fun selectPersonDetail(personId: Long?) {
        _uiState.update { it.copy(selectedPersonIdForDetail = personId) }
    }

    fun toggleLanguage() {
        val newLang = !_uiState.value.isBengali
        settingsManager.isBengali = newLang
        _uiState.update { it.copy(isBengali = newLang) }
    }

    fun unlockWithPin(pin: String): Boolean {
        if (pin == settingsManager.pinCode) {
            _uiState.update { it.copy(isPinLocked = false) }
            return true
        }
        return false
    }

    fun updatePinSecurity(enabled: Boolean, pin: String) {
        settingsManager.isPinLockEnabled = enabled
        settingsManager.pinCode = pin
        _uiState.update {
            it.copy(
                hasPinSet = enabled && pin.isNotBlank(),
                userMessage = if (it.isBengali) "পিন নিরাপত্তা আপডেট করা হয়েছে" else "PIN security updated"
            )
        }
    }

    // Search and Filters
    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setAccountsFilter(filter: String) {
        _uiState.update { it.copy(accountsFilter = filter) }
    }

    fun setExpenseCategoryFilter(category: String) {
        _uiState.update { it.copy(expenseCategoryFilter = category) }
    }

    fun setDateFilter(filter: DateRangeFilter, customStart: Long? = null, customEnd: Long? = null) {
        _uiState.update {
            it.copy(
                dateFilter = filter,
                customStartDate = customStart,
                customEndDate = customEnd
            )
        }
    }

    fun setSpreadsheetSorting(column: String) {
        _uiState.update { current ->
            if (current.spreadsheetSortColumn == column) {
                current.copy(spreadsheetSortAscending = !current.spreadsheetSortAscending)
            } else {
                current.copy(spreadsheetSortColumn = column, spreadsheetSortAscending = true)
            }
        }
    }

    // CRUD Actions
    fun createNewBusiness(name: String, owner: String, phone: String, address: String, currency: String) {
        viewModelScope.launch {
            val biz = BusinessEntity(
                name = name,
                ownerName = owner,
                phone = phone,
                address = address,
                currencySymbol = currency
            )
            val newId = repository.insertBusiness(biz)
            switchBusiness(newId)
            _uiState.update {
                it.copy(userMessage = if (it.isBengali) "নতুন ব্যবসা যোগ হয়েছে!" else "New business created!")
            }
        }
    }

    fun updateBusinessDetails(business: BusinessEntity) {
        viewModelScope.launch {
            repository.updateBusiness(business)
            _uiState.update {
                it.copy(
                    activeBusiness = business,
                    userMessage = if (it.isBengali) "ব্যবসার তথ্য আপডেট হয়েছে" else "Business updated"
                )
            }
        }
    }

    fun savePerson(person: PersonEntity) {
        viewModelScope.launch {
            if (person.id == 0L) {
                repository.insertPerson(person)
            } else {
                repository.updatePerson(person)
            }
            _uiState.update {
                it.copy(userMessage = if (it.isBengali) "ব্যক্তির তথ্য সংরক্ষিত হয়েছে" else "Person details saved")
            }
        }
    }

    fun deletePerson(personId: Long) {
        viewModelScope.launch {
            repository.deletePerson(personId)
            _uiState.update {
                it.copy(
                    selectedPersonIdForDetail = null,
                    userMessage = if (it.isBengali) "ব্যক্তি এবং লেনদেন মুছে ফেলা হয়েছে" else "Person deleted"
                )
            }
        }
    }

    fun saveTransaction(
        id: Long = 0,
        personId: Long?,
        personName: String,
        type: TransactionType,
        amount: Double,
        date: Long,
        description: String,
        paymentMethod: PaymentMethod,
        reference: String = "",
        note: String = ""
    ) {
        val bizId = _uiState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            val (debit, credit) = when (type) {
                TransactionType.DUE_GIVEN -> Pair(amount, 0.0)
                TransactionType.DUE_TAKEN -> Pair(0.0, amount)
                TransactionType.RECEIVED -> Pair(0.0, amount)
                TransactionType.PAID -> Pair(amount, 0.0)
                TransactionType.SALE -> Pair(amount, 0.0)
                TransactionType.PURCHASE -> Pair(0.0, amount)
                TransactionType.EXPENSE -> Pair(0.0, amount)
                TransactionType.INCOME -> Pair(amount, 0.0)
            }

            val txn = TransactionEntity(
                id = id,
                businessId = bizId,
                personId = personId,
                personName = personName,
                type = type.name,
                amount = amount,
                date = date,
                description = description.ifBlank { type.label(_uiState.value.isBengali) },
                paymentMethod = paymentMethod.name,
                referenceNumber = reference,
                note = note,
                debit = debit,
                credit = credit
            )

            if (id == 0L) {
                repository.insertTransaction(txn)
            } else {
                repository.updateTransaction(txn)
            }

            _uiState.update {
                it.copy(userMessage = if (it.isBengali) "লেনদেন সফলভাবে সংরক্ষিত!" else "Transaction saved!")
            }
        }
    }

    // Spreadsheet Fast Inline Update
    fun updateSpreadsheetCell(
        transaction: TransactionEntity,
        newField: String,
        newValue: String
    ) {
        viewModelScope.launch {
            var updated = transaction
            when (newField) {
                "personName" -> updated = updated.copy(personName = newValue)
                "description" -> updated = updated.copy(description = newValue)
                "amount" -> {
                    val num = newValue.toDoubleOrNull() ?: transaction.amount
                    val debit = if (updated.debit > 0) num else 0.0
                    val credit = if (updated.credit > 0) num else 0.0
                    updated = updated.copy(amount = num, debit = debit, credit = credit)
                }
                "debit" -> {
                    val num = newValue.toDoubleOrNull() ?: transaction.debit
                    updated = updated.copy(debit = num, amount = if (num > 0) num else updated.credit)
                }
                "credit" -> {
                    val num = newValue.toDoubleOrNull() ?: transaction.credit
                    updated = updated.copy(credit = num, amount = if (num > 0) num else updated.debit)
                }
                "note" -> updated = updated.copy(note = newValue)
            }
            repository.updateTransaction(updated)
        }
    }

    fun duplicateTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            val copy = transaction.copy(
                id = 0,
                date = System.currentTimeMillis(),
                description = "${transaction.description} (কপি)",
                createdAt = System.currentTimeMillis()
            )
            repository.insertTransaction(copy)
            _uiState.update {
                it.copy(userMessage = if (it.isBengali) "লেনদেন ডুপ্লিকেট করা হয়েছে" else "Transaction duplicated")
            }
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            deletedTxnStack.add(transaction)
            repository.deleteTransaction(transaction.id)
            _uiState.update {
                it.copy(
                    canUndo = true,
                    userMessage = if (it.isBengali) "লেনদেন মুছে ফেলা হয়েছে (Undo করতে পারেন)" else "Transaction deleted (Tap Undo)"
                )
            }
        }
    }

    fun undoLastDeletion() {
        val last = deletedTxnStack.removeLastOrNull() ?: return
        viewModelScope.launch {
            repository.insertTransaction(last.copy(id = 0))
            _uiState.update {
                it.copy(
                    canUndo = deletedTxnStack.isNotEmpty(),
                    userMessage = if (it.isBengali) "লেনদেন পুনরুদ্ধার করা হয়েছে!" else "Transaction restored!"
                )
            }
        }
    }

    fun saveExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            if (expense.id == 0L) {
                repository.insertExpense(expense)
            } else {
                repository.updateExpense(expense)
            }
            _uiState.update {
                it.copy(userMessage = if (it.isBengali) "খরচ সফলভাবে যোগ হয়েছে" else "Expense saved")
            }
        }
    }

    fun deleteExpense(expenseId: Long) {
        viewModelScope.launch {
            repository.deleteExpense(expenseId)
            _uiState.update {
                it.copy(userMessage = if (it.isBengali) "খরচ মুছে ফেলা হয়েছে" else "Expense deleted")
            }
        }
    }

    fun saveSalePurchase(item: SalePurchaseEntity) {
        viewModelScope.launch {
            repository.insertSalePurchase(item)
            _uiState.update {
                it.copy(userMessage = if (it.isBengali) "হিসাব সংরক্ষিত হয়েছে" else "Item saved")
            }
        }
    }

    // Export helpers
    suspend fun getExportCsvData(): String {
        val bizId = _uiState.value.activeBusiness?.id ?: return ""
        return repository.generateCsvData(bizId, _uiState.value.isBengali)
    }

    fun getPersonStatementText(personId: Long): String {
        val personWithSummary = _uiState.value.personsWithSummary.find { it.person.id == personId } ?: return ""
        val personTxns = _uiState.value.allTransactions.filter { it.personId == personId }
        val currSymbol = _uiState.value.activeBusiness?.currencySymbol ?: "৳"
        return repository.generatePersonStatement(
            personWithSummary.person,
            personTxns,
            personWithSummary,
            currSymbol,
            _uiState.value.isBengali
        )
    }

    suspend fun createFullBackup(): String {
        val bizId = _uiState.value.activeBusiness?.id ?: return "{}"
        return repository.createBackupJson(bizId)
    }

    fun restoreBackup(json: String) {
        viewModelScope.launch {
            val success = repository.restoreFromJson(json)
            if (success) {
                _uiState.update {
                    it.copy(userMessage = if (it.isBengali) "ব্যাকআপ সফলভাবে পুনরুদ্ধার হয়েছে!" else "Backup restored successfully!")
                }
            } else {
                _uiState.update {
                    it.copy(userMessage = if (it.isBengali) "ব্যাকআপ ফাইল সঠিক নয়!" else "Invalid backup file!")
                }
            }
        }
    }

    fun clearUserMessage() {
        _uiState.update { it.copy(userMessage = null) }
    }
}

// Helper data class
private data class Quintuple<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)
