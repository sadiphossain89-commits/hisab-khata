package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PersonWithSummary
import com.example.ui.components.NumberFormatHelper
import com.example.ui.components.PersonCard
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.viewmodel.AccountingUiState

@Composable
fun AccountsScreen(
    uiState: AccountingUiState,
    onSearchChange: (String) -> Unit,
    onFilterChange: (String) -> Unit,
    onSelectPerson: (Long) -> Unit,
    onAddNewPerson: () -> Unit
) {
    val currency = uiState.activeBusiness?.currencySymbol ?: "৳"
    val isBn = uiState.isBengali

    // Filter persons by search query and category tab
    val filteredPersons = uiState.personsWithSummary.filter { p ->
        val queryMatches = p.person.name.contains(uiState.searchQuery, ignoreCase = true) ||
                p.person.phone.contains(uiState.searchQuery, ignoreCase = true)

        val categoryMatches = when (uiState.accountsFilter) {
            "DUE_RECEIVABLE" -> p.currentBalance > 0
            "DUE_PAYABLE" -> p.currentBalance < 0
            "ZERO_BALANCE" -> p.currentBalance == 0.0
            else -> true
        }

        queryMatches && categoryMatches
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddNewPerson,
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("fab_add_person")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = "Add Person")
                    Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                    Text(
                        text = if (isBn) "+ নতুন ব্যক্তি" else "+ Add Person",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // 1. Search Bar
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = {
                        Text(
                            text = if (isBn) "ব্যক্তির নাম বা মোবাইল নম্বর দিয়ে খুঁজুন..." else "Search by name or phone...",
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("accounts_search_input")
                )
            }

            // 2. Filter Chips Row
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = uiState.accountsFilter == "ALL",
                        onClick = { onFilterChange("ALL") },
                        label = {
                            Text(
                                (if (isBn) "সকল (" else "All (") +
                                        NumberFormatHelper.formatNumber(uiState.personsWithSummary.size, isBn) + ")"
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }

                val receivableCount = uiState.personsWithSummary.count { it.currentBalance > 0 }
                item {
                    FilterChip(
                        selected = uiState.accountsFilter == "DUE_RECEIVABLE",
                        onClick = { onFilterChange("DUE_RECEIVABLE") },
                        label = {
                            Text(
                                (if (isBn) "পাওনাদার বাকি (" else "Receivable (") +
                                        NumberFormatHelper.formatNumber(receivableCount, isBn) + ")"
                            )
                        }
                    )
                }

                val payableCount = uiState.personsWithSummary.count { it.currentBalance < 0 }
                item {
                    FilterChip(
                        selected = uiState.accountsFilter == "DUE_PAYABLE",
                        onClick = { onFilterChange("DUE_PAYABLE") },
                        label = {
                            Text(
                                (if (isBn) "দেনা বাকি (" else "Payable (") +
                                        NumberFormatHelper.formatNumber(payableCount, isBn) + ")"
                            )
                        }
                    )
                }

                val settledCount = uiState.personsWithSummary.count { it.currentBalance == 0.0 }
                item {
                    FilterChip(
                        selected = uiState.accountsFilter == "ZERO_BALANCE",
                        onClick = { onFilterChange("ZERO_BALANCE") },
                        label = {
                            Text(
                                (if (isBn) "শূন্য ব্যালেন্স (" else "Settled (") +
                                        NumberFormatHelper.formatNumber(settledCount, isBn) + ")"
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3. Persons List
            if (filteredPersons.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isBn) "কোনো ব্যক্তি বা হিসাব পাওয়া যায়নি।\n'+ নতুন ব্যক্তি' বাটনে চাপ দিয়ে যোগ করুন।"
                        else "No accounts found.\nTap '+ Add Person' to add customers.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredPersons, key = { it.person.id }) { personSummary ->
                        PersonCard(
                            personWithSummary = personSummary,
                            currencySymbol = currency,
                            isBengali = isBn,
                            onClick = { onSelectPerson(personSummary.person.id) }
                        )
                    }
                }
            }
        }
    }
}
