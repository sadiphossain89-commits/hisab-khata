package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Utility / Minimal Indigo & Slate Palette
val IndigoPrimary = Color(0xFF4F46E5)          // Tailwind indigo-600
val IndigoPrimaryDark = Color(0xFF4338CA)      // Tailwind indigo-700
val IndigoPrimaryLight = Color(0xFF818CF8)     // Tailwind indigo-400
val IndigoOnPrimary = Color(0xFFFFFFFF)
val IndigoContainer = Color(0xFFEEF2FF)        // Tailwind indigo-50
val IndigoOnContainer = Color(0xFF312E81)      // Tailwind indigo-900

// Aliases for compatibility
val EmeraldPrimary = IndigoPrimary
val EmeraldPrimaryDark = IndigoPrimaryLight
val EmeraldOnPrimary = IndigoOnPrimary
val EmeraldContainer = IndigoContainer
val EmeraldOnContainer = IndigoOnContainer

val SecondarySlate = Color(0xFF475569)        // Slate 600
val SecondarySlateDark = Color(0xFF94A3B8)    // Slate 400
val TertiaryAmber = Color(0xFFD97706)         // Amber 600
val TertiaryAmberDark = Color(0xFFF59E0B)

// Financial Semantic Colors (Clean Utility)
val PositiveGreen = Color(0xFF16A34A)          // Tailwind green-600
val PositiveGreenContainer = Color(0xFFDCFCE7) // Tailwind green-100
val PositiveGreenText = Color(0xFF15803D)      // Tailwind green-700

val NegativeRed = Color(0xFFEF4444)            // Tailwind red-500
val NegativeRedContainer = Color(0xFFFEE2E2)   // Tailwind red-100
val NegativeRedText = Color(0xFFB91C1C)        // Tailwind red-700

val WarningOrange = Color(0xFFF97316)          // Tailwind orange-500
val WarningOrangeContainer = Color(0xFFFFEDD5) // Tailwind orange-100

val InfoBlue = Color(0xFF2563EB)               // Tailwind blue-600
val InfoBlueContainer = Color(0xFFDBEAFE)      // Tailwind blue-100

// Neutrals - Clean Minimal
val LightBackground = Color(0xFFF3F4F9)        // As specified in Clean Utility spec
val LightSurface = Color(0xFFFFFFFF)           // Pure clean white
val LightSurfaceVariant = Color(0xFFF8FAFC)    // Slate 50
val LightBorder = Color(0xFFE2E8F0)            // Slate 200
val LightBorderSubtle = Color(0xFFF1F5F9)      // Slate 100
val LightOnSurface = Color(0xFF0F172A)         // Slate 900
val LightOnSurfaceVariant = Color(0xFF64748B)  // Slate 500

val DarkBackground = Color(0xFF0B0F19)         // Deep Slate Dark
val DarkSurface = Color(0xFF1E293B)            // Slate 800
val DarkSurfaceVariant = Color(0xFF334155)     // Slate 700
val DarkBorder = Color(0xFF475569)             // Slate 600
val DarkOnSurface = Color(0xFFF8FAFC)          // Slate 50
val DarkOnSurfaceVariant = Color(0xFF94A3B8)   // Slate 400

