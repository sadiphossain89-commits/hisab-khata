package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DateRangeFilter
import com.example.data.model.TransactionEntity
import com.example.ui.components.NumberFormatHelper
import com.example.ui.components.SpreadsheetCellEditDialog
import com.example.ui.components.SpreadsheetTableView
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.viewmodel.AccountingUiState
import kotlinx.coroutines.launch
import java.util.Calendar

@Composable
fun SpreadsheetScreen(
    uiState: AccountingUiState,
    onSearchChange: (String) -> Unit,
    onDateFilterChange: (DateRangeFilter) -> Unit,
    onSortColumn: (String) -> Unit,
    onUpdateCell: (TransactionEntity, String, String) -> Unit,
    onAddNewTransaction: () -> Unit,
    onDuplicateTransaction: (TransactionEntity) -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit,
    onUndo: () -> Unit,
    onExportCsv: suspend () -> String
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isBn = uiState.isBengali
    val currency = uiState.activeBusiness?.currencySymbol ?: "৳"

    var selectedViewMode by remember { mutableIntStateOf(0) } // 0: Spreadsheet Grid, 1: Mobile List
    var editingCellTransaction by remember { mutableStateOf<TransactionEntity?>(null) }
    var editingCellField by remember { mutableStateOf("") }
    var editingCellValue by remember { mutableStateOf("") }

    // Date filtering logic
    val now = Calendar.getInstance()
    val startOfToday = now.apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    val filteredTransactions = uiState.allTransactions.filter { txn ->
        val queryMatches = txn.personName.contains(uiState.searchQuery, ignoreCase = true) ||
                txn.description.contains(uiState.searchQuery, ignoreCase = true) ||
                txn.amount.toString().contains(uiState.searchQuery)

        val dateMatches = when (uiState.dateFilter) {
            DateRangeFilter.TODAY -> txn.date >= startOfToday
            DateRangeFilter.THIS_WEEK -> txn.date >= (startOfToday - 6 * 24 * 60 * 60 * 1000L)
            DateRangeFilter.THIS_MONTH -> txn.date >= (startOfToday - 30 * 24 * 60 * 60 * 1000L)
            DateRangeFilter.ALL -> true
            else -> true
        }

        queryMatches && dateMatches
    }

    if (editingCellTransaction != null) {
        SpreadsheetCellEditDialog(
            transaction = editingCellTransaction!!,
            fieldName = editingCellField,
            currentValue = editingCellValue,
            isBengali = isBn,
            onDismiss = { editingCellTransaction = null },
            onSave = { txn, field, value ->
                onUpdateCell(txn, field, value)
            }
        )
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddNewTransaction,
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("fab_spreadsheet_add_entry")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isBn) "+ নতুন এন্ট্রি" else "+ New Entry", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // View Mode Tab (Spreadsheet vs List)
            TabRow(
                selectedTabIndex = selectedViewMode,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = selectedViewMode == 0,
                    onClick = { selectedViewMode = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isBn) "স্প্রেডশীট টেবিল (Excel)" else "Spreadsheet Grid",
                                fontWeight = if (selectedViewMode == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                )
                Tab(
                    selected = selectedViewMode == 1,
                    onClick = { selectedViewMode = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FormatListBulleted, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isBn) "তালিকা ভিউ (List)" else "List View",
                                fontWeight = if (selectedViewMode == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                )
            }

            // Search Bar & CSV Export Action
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = {
                        Text(
                            text = if (isBn) "নাম বা বিবরণ দিয়ে খুঁজুন..." else "Search name or description...",
                            fontSize = 12.sp
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary)
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            val csvData = onExportCsv()
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, csvData)
                                type = "text/csv"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, if (isBn) "এক্সেল/CSV ফাইল শেয়ার করুন" else "Share Excel CSV"))
                        }
                    },
                    modifier = Modifier.testTag("export_csv_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = "Export CSV",
                        tint = EmeraldPrimary
                    )
                }
            }

            // Date Filter Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DateRangeFilter.values().take(4).forEach { filter ->
                    item {
                        FilterChip(
                            selected = uiState.dateFilter == filter,
                            onClick = { onDateFilterChange(filter) },
                            label = { Text(filter.label(isBn)) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Main Content: Grid vs List
            if (selectedViewMode == 0) {
                // Interactive Excel Spreadsheet Table
                SpreadsheetTableView(
                    transactions = filteredTransactions,
                    currencySymbol = currency,
                    isBengali = isBn,
                    sortColumn = uiState.spreadsheetSortColumn,
                    sortAscending = uiState.spreadsheetSortAscending,
                    canUndo = uiState.canUndo,
                    onSortColumn = onSortColumn,
                    onCellClick = { txn, field, value ->
                        editingCellTransaction = txn
                        editingCellField = field
                        editingCellValue = value
                    },
                    onAddNewRow = onAddNewTransaction,
                    onDuplicateRow = onDuplicateTransaction,
                    onDeleteRow = onDeleteTransaction,
                    onUndo = onUndo
                )
            } else {
                // Mobile Ledger List
                if (filteredTransactions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isBn) "কোনো লেনদেন রেকর্ড পাওয়া যায়নি" else "No transactions found",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredTransactions, key = { it.id }) { txn ->
                            TransactionRowItem(
                                transaction = txn,
                                currencySymbol = currency,
                                isBengali = isBn,
                                onClick = {
                                    editingCellTransaction = txn
                                    editingCellField = "amount"
                                    editingCellValue = txn.amount.toString()
                                },
                                onEdit = {
                                    editingCellTransaction = txn
                                    editingCellField = "amount"
                                    editingCellValue = txn.amount.toString()
                                },
                                onDelete = { onDeleteTransaction(txn) }
                            )
                        }
                    }
                }
            }
        }
    }
}
