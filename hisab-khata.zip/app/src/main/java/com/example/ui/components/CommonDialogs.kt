package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExpenseCategory
import com.example.data.model.ExpenseEntity
import com.example.data.model.PaymentMethod
import com.example.data.model.PersonEntity
import com.example.data.model.PersonType
import com.example.data.model.PersonWithSummary
import com.example.data.model.SalePurchaseEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.NegativeRed

// 1. ADD / EDIT TRANSACTION DIALOG
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionDialog(
    initialType: TransactionType = TransactionType.SALE,
    initialPersonId: Long? = null,
    persons: List<PersonEntity>,
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onSave: (
        personId: Long?,
        personName: String,
        type: TransactionType,
        amount: Double,
        date: Long,
        description: String,
        paymentMethod: PaymentMethod,
        reference: String,
        note: String
    ) -> Unit
) {
    var selectedType by remember { mutableStateOf(initialType) }
    var selectedPerson by remember {
        mutableStateOf(persons.find { it.id == initialPersonId })
    }
    var customPersonName by remember {
        mutableStateOf(selectedPerson?.name ?: "")
    }
    var amountText by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.CASH) }
    var referenceNumber by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var typeMenuExpanded by remember { mutableStateOf(false) }
    var personMenuExpanded by remember { mutableStateOf(false) }
    var paymentMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isBengali) "নতুন লেনদেন যোগ করুন" else "Add New Transaction",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Transaction Type Dropdown
                ExposedDropdownMenuBox(
                    expanded = typeMenuExpanded,
                    onExpandedChange = { typeMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedType.label(isBengali),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isBengali) "লেনদেনের ধরন" else "Transaction Type") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = typeMenuExpanded,
                        onDismissRequest = { typeMenuExpanded = false }
                    ) {
                        TransactionType.values().forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.label(isBengali)) },
                                onClick = {
                                    selectedType = type
                                    typeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Person Selector Dropdown / Name Input
                ExposedDropdownMenuBox(
                    expanded = personMenuExpanded,
                    onExpandedChange = { personMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = customPersonName,
                        onValueChange = {
                            customPersonName = it
                            selectedPerson = null
                        },
                        label = { Text(if (isBengali) "ব্যক্তি / কাস্টমারের নাম *" else "Person / Customer Name *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = personMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryEditable)
                            .testTag("txn_person_name_input")
                    )
                    if (persons.isNotEmpty()) {
                        ExposedDropdownMenu(
                            expanded = personMenuExpanded,
                            onDismissRequest = { personMenuExpanded = false }
                        ) {
                            persons.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text("${p.name} (${p.phone})") },
                                    onClick = {
                                        selectedPerson = p
                                        customPersonName = p.name
                                        personMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Amount Field
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        if (it.isEmpty() || it.toDoubleOrNull() != null || it.endsWith(".")) {
                            amountText = it
                        }
                    },
                    label = { Text(if (isBengali) "টাকার পরিমাণ (Amount ৳) *" else "Amount (৳) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("txn_amount_input"),
                    leadingIcon = {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = EmeraldPrimary)
                    }
                )

                // Description Field
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text(if (isBengali) "বিবরণ (যেমন: পণ্য বিক্রয়, নগদ জমা)" else "Description") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Payment Method
                ExposedDropdownMenuBox(
                    expanded = paymentMenuExpanded,
                    onExpandedChange = { paymentMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedPaymentMethod.label(isBengali),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isBengali) "পেমেন্ট মাধ্যম" else "Payment Method") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = paymentMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = paymentMenuExpanded,
                        onDismissRequest = { paymentMenuExpanded = false }
                    ) {
                        PaymentMethod.values().forEach { method ->
                            DropdownMenuItem(
                                text = { Text(method.label(isBengali)) },
                                onClick = {
                                    selectedPaymentMethod = method
                                    paymentMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Reference / Note
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(if (isBengali) "নোট / রেফারেন্স নম্বর" else "Note / Reference") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = NegativeRed,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    if (customPersonName.isBlank()) {
                        errorMessage = if (isBengali) "দয়া করে ব্যক্তির নাম লিখুন" else "Please enter person name"
                        return@Button
                    }
                    if (amount == null || amount <= 0.0) {
                        errorMessage = if (isBengali) "দয়া করে সঠিক টাকার পরিমাণ লিখুন" else "Please enter valid amount"
                        return@Button
                    }

                    onSave(
                        selectedPerson?.id,
                        customPersonName.trim(),
                        selectedType,
                        amount,
                        System.currentTimeMillis(),
                        description.trim(),
                        selectedPaymentMethod,
                        referenceNumber.trim(),
                        note.trim()
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("save_txn_submit_btn")
            ) {
                Text(if (isBengali) "সংরক্ষণ করুন" else "Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel")
            }
        }
    )
}

// 2. ADD / EDIT PERSON DIALOG
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPersonDialog(
    initialPerson: PersonEntity? = null,
    businessId: Long,
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onSave: (PersonEntity) -> Unit
) {
    var name by remember { mutableStateOf(initialPerson?.name ?: "") }
    var phone by remember { mutableStateOf(initialPerson?.phone ?: "") }
    var address by remember { mutableStateOf(initialPerson?.address ?: "") }
    var selectedType by remember {
        mutableStateOf(
            try {
                PersonType.valueOf(initialPerson?.personType ?: PersonType.CUSTOMER.name)
            } catch (e: Exception) {
                PersonType.CUSTOMER
            }
        )
    }
    var openingBalanceText by remember {
        mutableStateOf(if (initialPerson != null && initialPerson.openingBalance > 0) initialPerson.openingBalance.toString() else "")
    }
    var openingBalanceType by remember { mutableStateOf(initialPerson?.openingBalanceType ?: "RECEIVABLE") }
    var note by remember { mutableStateOf(initialPerson?.note ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var typeMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialPerson == null) {
                    if (isBengali) "নতুন ব্যক্তি / কাস্টমার যোগ" else "Add New Customer/Person"
                } else {
                    if (isBengali) "ব্যক্তির তথ্য পরিবর্তন" else "Edit Person"
                },
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (isBengali) "পূর্ণ নাম *" else "Full Name *") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("person_name_input")
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(if (isBengali) "মোবাইল নম্বর" else "Mobile Number") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("person_phone_input")
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(if (isBengali) "ঠিকানা" else "Address") },
                    leadingIcon = { Icon(Icons.Default.Place, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )

                // Person Type Dropdown
                ExposedDropdownMenuBox(
                    expanded = typeMenuExpanded,
                    onExpandedChange = { typeMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedType.label(isBengali),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isBengali) "ব্যক্তির ধরন" else "Person Type") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = typeMenuExpanded,
                        onDismissRequest = { typeMenuExpanded = false }
                    ) {
                        PersonType.values().forEach { pt ->
                            DropdownMenuItem(
                                text = { Text(pt.label(isBengali)) },
                                onClick = {
                                    selectedType = pt
                                    typeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Opening Balance (if new person)
                if (initialPerson == null) {
                    OutlinedTextField(
                        value = openingBalanceText,
                        onValueChange = {
                            if (it.isEmpty() || it.toDoubleOrNull() != null || it.endsWith(".")) {
                                openingBalanceText = it
                            }
                        },
                        label = { Text(if (isBengali) "পূর্বের বাকি/ব্যালেন্স (যদি থাকে ৳)" else "Opening Balance (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (openingBalanceText.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = openingBalanceType == "RECEIVABLE",
                                onClick = { openingBalanceType = "RECEIVABLE" }
                            )
                            Text(text = if (isBengali) "পাবো (পাওনা)" else "Receivable", fontSize = 13.sp)

                            Spacer(modifier = Modifier.width(12.dp))

                            RadioButton(
                                selected = openingBalanceType == "PAYABLE",
                                onClick = { openingBalanceType = "PAYABLE" }
                            )
                            Text(text = if (isBengali) "দেবো (দেনা)" else "Payable", fontSize = 13.sp)
                        }
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(if (isBengali) "নোট" else "Note") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = NegativeRed,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = if (isBengali) "দয়া করে ব্যক্তির নাম লিখুন" else "Please enter person name"
                        return@Button
                    }
                    val openBal = openingBalanceText.toDoubleOrNull() ?: 0.0
                    val entity = (initialPerson ?: PersonEntity(businessId = businessId, name = "")).copy(
                        businessId = businessId,
                        name = name.trim(),
                        phone = phone.trim(),
                        address = address.trim(),
                        personType = selectedType.name,
                        openingBalance = openBal,
                        openingBalanceType = openingBalanceType,
                        note = note.trim(),
                        updatedAt = System.currentTimeMillis()
                    )
                    onSave(entity)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("save_person_submit_btn")
            ) {
                Text(if (isBengali) "সংরক্ষণ করুন" else "Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel")
            }
        }
    )
}

// 3. ADD EXPENSE DIALOG
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    businessId: Long,
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onSave: (ExpenseEntity) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.SHOP_RENT) }
    var amountText by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.CASH) }
    var note by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var categoryMenuExpanded by remember { mutableStateOf(false) }
    var paymentMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isBengali) "নতুন খরচ যোগ করুন" else "Add New Expense",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Category Dropdown
                ExposedDropdownMenuBox(
                    expanded = categoryMenuExpanded,
                    onExpandedChange = { categoryMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedCategory.label(isBengali),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isBengali) "খরচের খাত / Category *" else "Expense Category *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = categoryMenuExpanded,
                        onDismissRequest = { categoryMenuExpanded = false }
                    ) {
                        ExpenseCategory.values().forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.label(isBengali)) },
                                onClick = {
                                    selectedCategory = cat
                                    categoryMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Amount
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        if (it.isEmpty() || it.toDoubleOrNull() != null || it.endsWith(".")) {
                            amountText = it
                        }
                    },
                    label = { Text(if (isBengali) "টাকার পরিমাণ (৳) *" else "Amount (৳) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_amount_input"),
                    leadingIcon = {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = NegativeRed)
                    }
                )

                // Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text(if (isBengali) "খরচের বিবরণ" else "Description") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Payment Method
                ExposedDropdownMenuBox(
                    expanded = paymentMenuExpanded,
                    onExpandedChange = { paymentMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedPaymentMethod.label(isBengali),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isBengali) "পেমেন্ট মাধ্যম" else "Payment Method") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = paymentMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = paymentMenuExpanded,
                        onDismissRequest = { paymentMenuExpanded = false }
                    ) {
                        PaymentMethod.values().forEach { method ->
                            DropdownMenuItem(
                                text = { Text(method.label(isBengali)) },
                                onClick = {
                                    selectedPaymentMethod = method
                                    paymentMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Note
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(if (isBengali) "অতিরিক্ত নোট" else "Note") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = NegativeRed,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    if (amount == null || amount <= 0.0) {
                        errorMessage = if (isBengali) "দয়া করে খরচের টাকার পরিমাণ লিখুন" else "Please enter expense amount"
                        return@Button
                    }
                    val expense = ExpenseEntity(
                        businessId = businessId,
                        category = selectedCategory.label(isBengali),
                        amount = amount,
                        date = System.currentTimeMillis(),
                        description = description.trim().ifBlank { selectedCategory.label(isBengali) },
                        paymentMethod = selectedPaymentMethod.name,
                        note = note.trim()
                    )
                    onSave(expense)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = NegativeRed),
                modifier = Modifier.testTag("save_expense_submit_btn")
            ) {
                Text(if (isBengali) "খরচ সংরক্ষণ করুন" else "Save Expense")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel")
            }
        }
    )
}

// 4. ADD SALE / PURCHASE ITEM DIALOG WITH AUTO CALCULATIONS
@Composable
fun AddSalePurchaseDialog(
    type: String, // "SALE" or "PURCHASE"
    businessId: Long,
    persons: List<PersonEntity>,
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onSave: (SalePurchaseEntity) -> Unit
) {
    var personName by remember { mutableStateOf("") }
    var selectedPerson by remember { mutableStateOf<PersonEntity?>(null) }
    var productName by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("1") }
    var unitPriceText by remember { mutableStateOf("") }
    var paidAmountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val qty = quantityText.toDoubleOrNull() ?: 1.0
    val price = unitPriceText.toDoubleOrNull() ?: 0.0
    val totalAmount = qty * price
    val paid = paidAmountText.toDoubleOrNull() ?: 0.0
    val due = (totalAmount - paid).coerceAtLeast(0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (type == "SALE") {
                    if (isBengali) "নতুন বিক্রয় হিসাব (+)" else "New Sale Entry (+)"
                } else {
                    if (isBengali) "নতুন ক্রয় হিসাব (-)" else "New Purchase Entry (-)"
                },
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = personName,
                    onValueChange = { personName = it },
                    label = {
                        Text(
                            if (type == "SALE") {
                                if (isBengali) "কাস্টমারের নাম *" else "Customer Name *"
                            } else {
                                if (isBengali) "সাপ্লায়ার / মহাজনের নাম *" else "Supplier Name *"
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = productName,
                    onValueChange = { productName = it },
                    label = { Text(if (isBengali) "পণ্য / সেবার নাম *" else "Product/Item Name *") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text(if (isBengali) "পরিমাণ" else "Qty") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unitPriceText,
                        onValueChange = { unitPriceText = it },
                        label = { Text(if (isBengali) "একক দর (৳) *" else "Unit Price (৳) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1.5f)
                    )
                }

                // Auto calculated summary box
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isBengali) "মোট টাকা (Auto):" else "Total (Auto):",
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = NumberFormatHelper.formatMoney(totalAmount, "৳", isBengali),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isBengali) "অবশিষ্ট বাকি (Due):" else "Due Balance:",
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = NumberFormatHelper.formatMoney(due, "৳", isBengali),
                                fontWeight = FontWeight.Bold,
                                color = if (due > 0) NegativeRed else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = paidAmountText,
                    onValueChange = { paidAmountText = it },
                    label = { Text(if (isBengali) "পরিশোধকৃত টাকা (Paid ৳)" else "Paid Amount (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(if (isBengali) "নোট" else "Note") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = NegativeRed,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (personName.isBlank()) {
                        errorMessage = if (isBengali) "দয়া করে নাম লিখুন" else "Please enter name"
                        return@Button
                    }
                    if (productName.isBlank()) {
                        errorMessage = if (isBengali) "দয়া করে পণ্যের নাম লিখুন" else "Please enter product name"
                        return@Button
                    }
                    if (price <= 0.0) {
                        errorMessage = if (isBengali) "দয়া করে দর লিখুন" else "Please enter valid price"
                        return@Button
                    }

                    val item = SalePurchaseEntity(
                        businessId = businessId,
                        personId = selectedPerson?.id,
                        personName = personName.trim(),
                        type = type,
                        productName = productName.trim(),
                        quantity = qty,
                        unitPrice = price,
                        totalAmount = totalAmount,
                        paidAmount = paid,
                        dueAmount = due,
                        date = System.currentTimeMillis(),
                        note = note.trim()
                    )
                    onSave(item)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (type == "SALE") EmeraldPrimary else MaterialTheme.colorScheme.tertiary
                )
            ) {
                Text(if (isBengali) "সংরক্ষণ করুন" else "Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel")
            }
        }
    )
}

// 5. SPREADSHEET FAST CELL EDIT DIALOG
@Composable
fun SpreadsheetCellEditDialog(
    transaction: TransactionEntity,
    fieldName: String,
    currentValue: String,
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onSave: (TransactionEntity, String, String) -> Unit
) {
    var editValue by remember { mutableStateOf(currentValue) }

    val fieldTitle = when (fieldName) {
        "personName" -> if (isBengali) "নাম পরিবর্তন" else "Edit Name"
        "description" -> if (isBengali) "বিবরণ পরিবর্তন" else "Edit Description"
        "amount" -> if (isBengali) "টাকার পরিমাণ পরিবর্তন" else "Edit Amount"
        "debit" -> if (isBengali) "পাওনা/বিক্রয় (Debit)" else "Edit Debit"
        "credit" -> if (isBengali) "দেনা/ক্রয় (Credit)" else "Edit Credit"
        "note" -> if (isBengali) "নোট পরিবর্তন" else "Edit Note"
        else -> if (isBengali) "সেল এডিট" else "Edit Cell"
    }

    val isNumeric = fieldName in listOf("amount", "debit", "credit")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(fieldTitle, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = editValue,
                    onValueChange = { editValue = it },
                    keyboardOptions = if (isNumeric) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("spreadsheet_cell_editor_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(transaction, fieldName, editValue.trim())
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isBengali) "আপডেট করুন" else "Update")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel")
            }
        }
    )
}

// 6. CREATE BUSINESS DIALOG
@Composable
fun CreateBusinessDialog(
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onCreate: (name: String, owner: String, phone: String, address: String, currency: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("৳") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isBengali) "নতুন ব্যবসা তৈরি করুন" else "Create New Business",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (isBengali) "ব্যবসার নাম (যেমন: মেসার্স রহিম স্টোর) *" else "Business Name *") },
                    leadingIcon = { Icon(Icons.Default.Business, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_business_name_input")
                )

                OutlinedTextField(
                    value = owner,
                    onValueChange = { owner = it },
                    label = { Text(if (isBengali) "মালিকের নাম" else "Owner Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(if (isBengali) "মোবাইল নম্বর" else "Phone") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(if (isBengali) "দোকান / ব্যবসার ঠিকানা" else "Business Address") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = NegativeRed,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = if (isBengali) "দয়া করে ব্যবসার নাম লিখুন" else "Please enter business name"
                        return@Button
                    }
                    onCreate(name.trim(), owner.trim(), phone.trim(), address.trim(), currency)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("save_new_business_btn")
            ) {
                Text(if (isBengali) "তৈরি করুন" else "Create")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel")
            }
        }
    )
}

// 7. PIN SECURITY SETTINGS DIALOG
@Composable
fun SecurityPinDialog(
    isPinEnabled: Boolean,
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onSave: (Boolean, String) -> Unit
) {
    var enabled by remember { mutableStateOf(isPinEnabled) }
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isBengali) "অ্যাপ নিরাপত্তা ও পিন লক" else "App Security & PIN Lock",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = if (isBengali) "পিন লক চালু করুন" else "Enable PIN Lock")
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }

                if (enabled) {
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { if (it.length <= 6) pin = it },
                        label = { Text(if (isBengali) "নতুন ৪-৬ সংখ্যার পিন লিখুন" else "Enter 4-6 digit PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = { if (it.length <= 6) confirmPin = it },
                        label = { Text(if (isBengali) "পিন পুনরায় লিখুন" else "Confirm PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (error != null) {
                    Text(text = error!!, color = NegativeRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (enabled) {
                        if (pin.length < 4) {
                            error = if (isBengali) "পিন কমপক্ষে ৪ সংখ্যার হতে হবে" else "PIN must be at least 4 digits"
                            return@Button
                        }
                        if (pin != confirmPin) {
                            error = if (isBengali) "দুই পিন মেলেনি!" else "PINs do not match!"
                            return@Button
                        }
                    }
                    onSave(enabled, if (enabled) pin else "")
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isBengali) "সংরক্ষণ করুন" else "Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel")
            }
        }
    )
}

// 8. BACKUP & RESTORE DIALOG
@Composable
fun BackupRestoreDialog(
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onExportJson: () -> Unit,
    onRestoreJson: (String) -> Unit
) {
    var jsonInput by remember { mutableStateOf("") }
    var isRestoreMode by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isBengali) "ডেটা ব্যাকআপ ও রিস্টোর" else "Backup & Restore Data",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!isRestoreMode) {
                    Text(
                        text = if (isBengali) "আপনার সমস্ত হিসাব, কাস্টমার তালিকা ও খরচের তথ্যের নিরাপদ ব্যাকআপ কপি তৈরি বা কপি করতে পারেন।"
                        else "Create or copy a complete secure backup of all ledgers, customer accounts, and expenses.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Button(
                        onClick = { onExportJson() },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isBengali) "📋 ব্যাকআপ ফাইল কপি/শেয়ার করুন" else "📋 Export / Copy Backup JSON")
                    }

                    OutlinedButton(
                        onClick = { isRestoreMode = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isBengali) "📥 সংরক্ষিত ব্যাকআপ থেকে রিস্টোর" else "📥 Restore from Backup")
                    }
                } else {
                    Text(
                        text = if (isBengali) "নিচে ব্যাকআপ JSON টেক্সট পেস্ট করুন:" else "Paste Backup JSON text below:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = jsonInput,
                        onValueChange = { jsonInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        maxLines = 10
                    )

                    Button(
                        onClick = {
                            if (jsonInput.isNotBlank()) {
                                onRestoreJson(jsonInput)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isBengali) "রিস্টোর সম্পন্ন করুন" else "Confirm Restore")
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isBengali) "বন্ধ করুন" else "Close")
            }
        }
    )
}

// 9. DELETE CONFIRMATION DIALOG
@Composable
fun DeleteConfirmDialog(
    title: String,
    message: String,
    isBengali: Boolean,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = NegativeRed),
                modifier = Modifier.testTag("confirm_delete_btn")
            ) {
                Text(if (isBengali) "মুছে ফেলুন" else "Delete")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel")
            }
        }
    )
}
