package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.DashboardSummarySection
import com.example.ui.components.QuickActionsGrid
import com.example.ui.components.TransactionRowItem
import com.example.ui.viewmodel.AccountingUiState

@Composable
fun HomeScreen(
    uiState: AccountingUiState,
    onNavigateToTab: (Int) -> Unit,
    onOpenAddTransaction: (TransactionType) -> Unit,
    onOpenAddPerson: () -> Unit,
    onOpenAddExpense: () -> Unit,
    onOpenAddSale: () -> Unit,
    onOpenAddPurchase: () -> Unit,
    onTransactionClick: (TransactionEntity) -> Unit,
    onTransactionDelete: (TransactionEntity) -> Unit
) {
    val currency = uiState.activeBusiness?.currencySymbol ?: "৳"
    val isBn = uiState.isBengali

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_scrollable")
    ) {
        // 1. Dashboard Metric Summaries
        item {
            DashboardSummarySection(
                currencySymbol = currency,
                totalReceivable = uiState.totalReceivable,
                totalPayable = uiState.totalPayable,
                todaySales = uiState.todaySales,
                todayPurchases = uiState.todayPurchases,
                todayExpenses = uiState.todayExpenses,
                totalNetProfit = uiState.totalNetProfit,
                cashInHand = uiState.cashInHand,
                totalTransactionsCount = uiState.totalTransactionsCount,
                isBengali = isBn
            )
        }

        // 2. 7 Quick Actions
        item {
            QuickActionsGrid(
                isBengali = isBn,
                onAddPerson = onOpenAddPerson,
                onAddDueGiven = { onOpenAddTransaction(TransactionType.DUE_GIVEN) },
                onAddDueTaken = { onOpenAddTransaction(TransactionType.DUE_TAKEN) },
                onAddReceived = { onOpenAddTransaction(TransactionType.RECEIVED) },
                onAddExpense = onOpenAddExpense,
                onAddSale = onOpenAddSale,
                onAddPurchase = onOpenAddPurchase
            )
        }

        // 3. Recent Transactions Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isBn) "সর্বশেষ লেনদেনসমূহ (Recent)" else "Recent Transactions",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                )

                TextButton(
                    onClick = { onNavigateToTab(2) }, // Navigate to Spreadsheet tab
                    modifier = Modifier.testTag("view_all_transactions_btn")
                ) {
                    Text(
                        text = if (isBn) "সব দেখুন >" else "View All >",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // 4. Recent Transactions List (Top 15)
        val recentTransactions = uiState.allTransactions.take(15)
        if (recentTransactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isBn) "কোনো লেনদেন এখনো হয়নি।\nউপরে Quick Action থেকে হিসাব যোগ করুন।"
                        else "No recent transactions.\nUse quick actions above to add entries.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        } else {
            items(recentTransactions, key = { it.id }) { txn ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    TransactionRowItem(
                        transaction = txn,
                        currencySymbol = currency,
                        isBengali = isBn,
                        onClick = { onTransactionClick(txn) },
                        onEdit = { onTransactionClick(txn) },
                        onDelete = { onTransactionDelete(txn) }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
