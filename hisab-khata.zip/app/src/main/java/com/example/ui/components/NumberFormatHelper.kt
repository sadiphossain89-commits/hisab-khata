package com.example.ui.components

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object NumberFormatHelper {
    private val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    fun toBengaliDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(bnDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatMoney(amount: Double, currencySymbol: String = "৳", isBn: Boolean = true): String {
        val formattedNumber = String.format(Locale.US, "%,.2f", amount)
        val text = "$currencySymbol $formattedNumber"
        return if (isBn) toBengaliDigits(text) else text
    }

    fun formatNumber(number: Number, isBn: Boolean = true): String {
        val str = number.toString()
        return if (isBn) toBengaliDigits(str) else str
    }

    fun formatDate(timestamp: Long, isBn: Boolean = true): String {
        val sdf = SimpleDateFormat("dd MMM, yyyy", if (isBn) Locale("bn", "BD") else Locale.ENGLISH)
        val dateStr = sdf.format(Date(timestamp))
        return if (isBn) toBengaliDigits(dateStr) else dateStr
    }

    fun formatDateTime(timestamp: Long, isBn: Boolean = true): String {
        val sdf = SimpleDateFormat("dd/MM/yy hh:mm a", Locale.getDefault())
        val dateStr = sdf.format(Date(timestamp))
        return if (isBn) toBengaliDigits(dateStr) else dateStr
    }
}
