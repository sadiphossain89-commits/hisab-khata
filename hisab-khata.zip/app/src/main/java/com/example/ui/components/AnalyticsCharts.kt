package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExpenseEntity
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.NegativeRed
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.TertiaryAmber
import com.example.ui.theme.WarningOrange

@Composable
fun CashFlowBarChart(
    sales: Double,
    purchases: Double,
    expenses: Double,
    currencySymbol: String,
    isBengali: Boolean
) {
    val maxVal = maxOf(sales, purchases, expenses, 1.0)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (isBengali) "আয়, ব্যয় ও ক্রয়ের গ্রাফিকাল তুলনা" else "Sales vs Purchase vs Expense",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Chart Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val barWidth = (canvasWidth / 5f)

                // Background grid lines
                drawLine(
                    color = Color.LightGray.copy(alpha = 0.4f),
                    start = Offset(0f, canvasHeight * 0.25f),
                    end = Offset(canvasWidth, canvasHeight * 0.25f),
                    strokeWidth = 1f
                )
                drawLine(
                    color = Color.LightGray.copy(alpha = 0.4f),
                    start = Offset(0f, canvasHeight * 0.75f),
                    end = Offset(canvasWidth, canvasHeight * 0.75f),
                    strokeWidth = 1f
                )

                // 3 Bars: Sales (Green), Purchases (Amber), Expenses (Red)
                val salesHeight = ((sales / maxVal) * (canvasHeight - 30f)).toFloat()
                val purchasesHeight = ((purchases / maxVal) * (canvasHeight - 30f)).toFloat()
                val expensesHeight = ((expenses / maxVal) * (canvasHeight - 30f)).toFloat()

                // Sales Bar
                val bar1X = (canvasWidth / 6f) - (barWidth / 2f)
                drawRoundRect(
                    color = PositiveGreen,
                    topLeft = Offset(bar1X, canvasHeight - salesHeight - 10f),
                    size = Size(barWidth, salesHeight.coerceAtLeast(8f)),
                    cornerRadius = CornerRadius(12f, 12f)
                )

                // Purchases Bar
                val bar2X = (canvasWidth / 2f) - (barWidth / 2f)
                drawRoundRect(
                    color = TertiaryAmber,
                    topLeft = Offset(bar2X, canvasHeight - purchasesHeight - 10f),
                    size = Size(barWidth, purchasesHeight.coerceAtLeast(8f)),
                    cornerRadius = CornerRadius(12f, 12f)
                )

                // Expenses Bar
                val bar3X = (5f * canvasWidth / 6f) - (barWidth / 2f)
                drawRoundRect(
                    color = NegativeRed,
                    topLeft = Offset(bar3X, canvasHeight - expensesHeight - 10f),
                    size = Size(barWidth, expensesHeight.coerceAtLeast(8f)),
                    cornerRadius = CornerRadius(12f, 12f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Legend / Values
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                ChartLegendItem(
                    color = PositiveGreen,
                    label = if (isBengali) "বিক্রয়" else "Sales",
                    amount = NumberFormatHelper.formatMoney(sales, currencySymbol, isBengali)
                )
                ChartLegendItem(
                    color = TertiaryAmber,
                    label = if (isBengali) "ক্রয়" else "Purchase",
                    amount = NumberFormatHelper.formatMoney(purchases, currencySymbol, isBengali)
                )
                ChartLegendItem(
                    color = NegativeRed,
                    label = if (isBengali) "খরচ" else "Expense",
                    amount = NumberFormatHelper.formatMoney(expenses, currencySymbol, isBengali)
                )
            }
        }
    }
}

@Composable
fun ChartLegendItem(color: Color, label: String, amount: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = CircleShape,
                color = color,
                modifier = Modifier.size(10.dp)
            ) {}
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = amount,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = color,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
fun ExpenseCategoryBreakdown(
    expenses: List<ExpenseEntity>,
    currencySymbol: String,
    isBengali: Boolean
) {
    val totalExpense = expenses.sumOf { it.amount }.coerceAtLeast(1.0)
    val grouped = expenses.groupBy { it.category }
        .mapValues { it.value.sumOf { e -> e.amount } }
        .toList()
        .sortedByDescending { it.second }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (isBengali) "খাত অনুযায়ী খরচের বিবরণ" else "Expense by Category",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (grouped.isEmpty()) {
                Text(
                    text = if (isBengali) "কোনো খরচের তথ্য নেই" else "No expense records",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            } else {
                grouped.forEach { (category, amount) ->
                    val percentage = (amount / totalExpense).toFloat()
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = category,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                            )
                            Text(
                                text = "${NumberFormatHelper.formatMoney(amount, currencySymbol, isBengali)} (${NumberFormatHelper.formatNumber((percentage * 100).toInt(), isBengali)}%)",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { percentage },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = EmeraldPrimary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        )
                    }
                }
            }
        }
    }
}
