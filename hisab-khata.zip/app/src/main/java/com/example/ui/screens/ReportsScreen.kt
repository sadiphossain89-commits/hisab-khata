package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CashFlowBarChart
import com.example.ui.components.NumberFormatHelper
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.NegativeRed
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.TertiaryAmber
import com.example.ui.viewmodel.AccountingUiState
import kotlinx.coroutines.launch

@Composable
fun ReportsScreen(
    uiState: AccountingUiState,
    onToggleLanguage: () -> Unit,
    onOpenSecurityPin: () -> Unit,
    onOpenBackupRestore: () -> Unit,
    onExportCsv: suspend () -> String
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isBn = uiState.isBengali
    val currency = uiState.activeBusiness?.currencySymbol ?: "৳"

    val totalSales = uiState.allTransactions.filter { it.type == "SALE" || it.type == "INCOME" }.sumOf { it.amount }
    val totalPurchases = uiState.allTransactions.filter { it.type == "PURCHASE" }.sumOf { it.amount }
    val totalExpenses = uiState.allExpenses.sumOf { it.amount }
    val totalCosts = totalPurchases + totalExpenses
    val netProfit = totalSales - totalCosts

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Profit & Loss Summary Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isBn) "লাভ-ক্ষতির সামগ্রিক বিবরণী" else "Profit & Loss Summary",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Icon(
                            imageVector = Icons.Default.Assessment,
                            contentDescription = null,
                            tint = EmeraldPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    ReportRow(
                        label = if (isBn) "(+) মোট বিক্রয় ও আয়" else "(+) Total Sales & Income",
                        amount = NumberFormatHelper.formatMoney(totalSales, currency, isBn),
                        color = PositiveGreen
                    )
                    ReportRow(
                        label = if (isBn) "(-) মোট মাল ক্রয়" else "(-) Total Purchases",
                        amount = NumberFormatHelper.formatMoney(totalPurchases, currency, isBn),
                        color = TertiaryAmber
                    )
                    ReportRow(
                        label = if (isBn) "(-) মোট ব্যবসার খরচ" else "(-) Total Expenses",
                        amount = NumberFormatHelper.formatMoney(totalExpenses, currency, isBn),
                        color = NegativeRed
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (netProfit >= 0) {
                                if (isBn) "মোট নিট লাভ (Net Profit):" else "Net Profit:"
                            } else {
                                if (isBn) "মোট নিট ক্ষতি (Net Loss):" else "Net Loss:"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = (if (netProfit >= 0) "+ " else "- ") +
                                    NumberFormatHelper.formatMoney(kotlin.math.abs(netProfit), currency, isBn),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = if (netProfit >= 0) PositiveGreen else NegativeRed,
                                fontSize = 20.sp
                            )
                        )
                    }
                }
            }
        }

        // 2. Graphical Visual Bar Chart
        item {
            CashFlowBarChart(
                sales = totalSales,
                purchases = totalPurchases,
                expenses = totalExpenses,
                currencySymbol = currency,
                isBengali = isBn
            )
        }

        // 3. Export & Share Tools
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isBn) "এক্সপোর্ট ও শেয়ারিং টুলস" else "Export & Share Tools",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val csv = onExportCsv()
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, csv)
                                    type = "text/csv"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, if (isBn) "এক্সেল/CSV ফাইল শেয়ার করুন" else "Share Excel CSV"))
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_export_csv_btn")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = if (isBn) "📊 Excel / Google Sheets CSV এক্সপোর্ট" else "📊 Export Excel / Sheets CSV")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = onOpenBackupRestore,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_backup_btn")
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = if (isBn) "💾 সম্পূর্ণ ডেটা ব্যাকআপ ও রিস্টোর (JSON)" else "💾 Full Backup & Restore (JSON)")
                    }
                }
            }
        }

        // 4. App Settings & Security
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isBn) "অ্যাপ সেটিংস ও নিরাপত্তা" else "Settings & Security",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onToggleLanguage,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBn) "ভাষা পরিবর্তন (English)" else "Switch to বাংলা (Bengali)"
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = onOpenSecurityPin,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBn) "অ্যাপ পাসওয়ার্ড / পিন নিরাপত্তা সেট করুন" else "Set App PIN / Password Lock"
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}

@Composable
fun ReportRow(label: String, amount: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
        Text(
            text = amount,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = color)
        )
    }
}
