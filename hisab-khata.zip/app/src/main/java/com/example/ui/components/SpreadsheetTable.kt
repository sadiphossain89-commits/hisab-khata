package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionEntity
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.NegativeRed
import com.example.ui.theme.PositiveGreen

@Composable
fun SpreadsheetTableView(
    transactions: List<TransactionEntity>,
    currencySymbol: String,
    isBengali: Boolean,
    sortColumn: String,
    sortAscending: Boolean,
    canUndo: Boolean,
    onSortColumn: (String) -> Unit,
    onCellClick: (TransactionEntity, String, String) -> Unit, // (txn, fieldName, currentValue)
    onAddNewRow: () -> Unit,
    onDuplicateRow: (TransactionEntity) -> Unit,
    onDeleteRow: (TransactionEntity) -> Unit,
    onUndo: () -> Unit
) {
    val hScrollState = rememberScrollState()

    // Fixed widths for columns to create genuine Excel / Google Sheets experience
    val colDateWidth = 100.dp
    val colNameWidth = 130.dp
    val colDescWidth = 150.dp
    val colDebitWidth = 105.dp
    val colCreditWidth = 105.dp
    val colReceivedWidth = 105.dp
    val colBalanceWidth = 115.dp
    val colActionWidth = 90.dp
    val totalTableWidth = colDateWidth + colNameWidth + colDescWidth + colDebitWidth + colCreditWidth + colReceivedWidth + colBalanceWidth + colActionWidth

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Quick Action Bar for Spreadsheet
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ElevatedButton(
                onClick = onAddNewRow,
                colors = ButtonDefaults.elevatedButtonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("spreadsheet_add_new_row_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isBengali) "+ নতুন হিসাব" else "+ New Row",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            if (canUndo) {
                OutlinedButton(
                    onClick = onUndo,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("spreadsheet_undo_btn")
                ) {
                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isBengali) "পূর্বাবস্থায় (Undo)" else "Undo", fontSize = 12.sp)
                }
            }
        }

        // Main Horizontal Scrollable Spreadsheet Box
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .horizontalScroll(hScrollState)
        ) {
            Column(
                modifier = Modifier.width(totalTableWidth)
            ) {
                // Sticky Header Row (Excel Green Palette)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(EmeraldPrimary)
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HeaderCell(
                        text = if (isBengali) "তারিখ 📅" else "Date 📅",
                        width = colDateWidth,
                        sortKey = "date",
                        activeSort = sortColumn,
                        isAsc = sortAscending,
                        onSort = onSortColumn
                    )
                    HeaderCell(
                        text = if (isBengali) "নাম 👤" else "Name 👤",
                        width = colNameWidth,
                        sortKey = "name",
                        activeSort = sortColumn,
                        isAsc = sortAscending,
                        onSort = onSortColumn
                    )
                    HeaderCell(
                        text = if (isBengali) "বিবরণ 📝" else "Description 📝",
                        width = colDescWidth,
                        sortKey = "desc",
                        activeSort = sortColumn,
                        isAsc = sortAscending,
                        onSort = onSortColumn
                    )
                    HeaderCell(
                        text = if (isBengali) "পাওনা/বিক্রয় (+)" else "Debit / Sale (+)",
                        width = colDebitWidth,
                        sortKey = "debit",
                        activeSort = sortColumn,
                        isAsc = sortAscending,
                        onSort = onSortColumn
                    )
                    HeaderCell(
                        text = if (isBengali) "দেনা/ক্রয় (-)" else "Credit / Buy (-)",
                        width = colCreditWidth,
                        sortKey = "credit",
                        activeSort = sortColumn,
                        isAsc = sortAscending,
                        onSort = onSortColumn
                    )
                    HeaderCell(
                        text = if (isBengali) "টাকা জমা 💰" else "Received 💰",
                        width = colReceivedWidth,
                        sortKey = "amount",
                        activeSort = sortColumn,
                        isAsc = sortAscending,
                        onSort = onSortColumn
                    )
                    HeaderCell(
                        text = if (isBengali) "ব্যালেন্স" else "Balance",
                        width = colBalanceWidth,
                        sortKey = "balance",
                        activeSort = sortColumn,
                        isAsc = sortAscending,
                        onSort = onSortColumn
                    )
                    Box(
                        modifier = Modifier.width(colActionWidth),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isBengali) "অ্যাকশন" else "Action",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                HorizontalDivider(thickness = 2.dp, color = EmeraldPrimary)

                if (transactions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isBengali) "কোনো লেনদেনের হিসাব পাওয়া যায়নি\n'+ নতুন হিসাব' বাটনে চাপ দিন" else "No ledger rows yet.\nTap '+ New Row' to add entries.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                } else {
                    var cumulativeBalance = 0.0
                    val sortedTxns = when (sortColumn) {
                        "date" -> if (sortAscending) transactions.sortedBy { it.date } else transactions.sortedByDescending { it.date }
                        "name" -> if (sortAscending) transactions.sortedBy { it.personName } else transactions.sortedByDescending { it.personName }
                        "debit" -> if (sortAscending) transactions.sortedBy { it.debit } else transactions.sortedByDescending { it.debit }
                        "credit" -> if (sortAscending) transactions.sortedBy { it.credit } else transactions.sortedByDescending { it.credit }
                        "amount" -> if (sortAscending) transactions.sortedBy { it.amount } else transactions.sortedByDescending { it.amount }
                        else -> transactions
                    }

                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        itemsIndexed(sortedTxns) { index, txn ->
                            val isEvenRow = index % 2 == 0
                            val rowBg = if (isEvenRow) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            val rowBalance = txn.debit - txn.credit
                            cumulativeBalance += rowBalance

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(rowBg)
                                    .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Date Cell
                                CellText(
                                    text = NumberFormatHelper.formatDate(txn.date, isBengali),
                                    width = colDateWidth,
                                    isMono = true,
                                    onClick = { onCellClick(txn, "date", txn.date.toString()) }
                                )

                                // Name Cell
                                CellText(
                                    text = txn.personName.ifBlank { if (isBengali) "সাধারণ" else "General" },
                                    width = colNameWidth,
                                    fontWeight = FontWeight.SemiBold,
                                    onClick = { onCellClick(txn, "personName", txn.personName) }
                                )

                                // Description Cell
                                CellText(
                                    text = txn.description.ifBlank { "-" },
                                    width = colDescWidth,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    onClick = { onCellClick(txn, "description", txn.description) }
                                )

                                // Debit Cell (পাওনা / বাকি দেওয়া)
                                CellText(
                                    text = if (txn.debit > 0) NumberFormatHelper.formatMoney(txn.debit, currencySymbol, isBengali) else "-",
                                    width = colDebitWidth,
                                    color = if (txn.debit > 0) PositiveGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (txn.debit > 0) FontWeight.Bold else FontWeight.Normal,
                                    alignment = Alignment.CenterEnd,
                                    isMono = true,
                                    onClick = { onCellClick(txn, "debit", txn.debit.toString()) }
                                )

                                // Credit Cell (দেনা / ক্রয়)
                                CellText(
                                    text = if (txn.credit > 0) NumberFormatHelper.formatMoney(txn.credit, currencySymbol, isBengali) else "-",
                                    width = colCreditWidth,
                                    color = if (txn.credit > 0) NegativeRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (txn.credit > 0) FontWeight.Bold else FontWeight.Normal,
                                    alignment = Alignment.CenterEnd,
                                    isMono = true,
                                    onClick = { onCellClick(txn, "credit", txn.credit.toString()) }
                                )

                                // Received Cell (জমা)
                                CellText(
                                    text = NumberFormatHelper.formatMoney(txn.amount, currencySymbol, isBengali),
                                    width = colReceivedWidth,
                                    alignment = Alignment.CenterEnd,
                                    isMono = true,
                                    onClick = { onCellClick(txn, "amount", txn.amount.toString()) }
                                )

                                // Running Balance Cell
                                CellText(
                                    text = (if (rowBalance >= 0) "+ " else "- ") + NumberFormatHelper.formatMoney(
                                        kotlin.math.abs(rowBalance),
                                        currencySymbol,
                                        isBengali
                                    ),
                                    width = colBalanceWidth,
                                    color = if (rowBalance >= 0) PositiveGreen else NegativeRed,
                                    fontWeight = FontWeight.Bold,
                                    alignment = Alignment.CenterEnd,
                                    isMono = true,
                                    onClick = { onCellClick(txn, "note", txn.note) }
                                )

                                // Actions (Duplicate / Delete)
                                Row(
                                    modifier = Modifier.width(colActionWidth),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { onDuplicateRow(txn) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Duplicate",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onDeleteRow(txn) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = NegativeRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Spreadsheet Footer Summary
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = (if (isBengali) "মোট এন্ট্রি: " else "Total Rows: ") + NumberFormatHelper.formatNumber(transactions.size, isBengali),
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                )

                val sumDebit = transactions.sumOf { it.debit }
                val sumCredit = transactions.sumOf { it.credit }
                Text(
                    text = (if (isBengali) "পাওনা: " else "Debit: ") + NumberFormatHelper.formatMoney(sumDebit, currencySymbol, isBengali) +
                            " | " + (if (isBengali) "দেনা: " else "Credit: ") + NumberFormatHelper.formatMoney(sumCredit, currencySymbol, isBengali),
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }
    }
}

@Composable
fun HeaderCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    sortKey: String,
    activeSort: String,
    isAsc: Boolean,
    onSort: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .width(width)
            .clickable { onSort(sortKey) }
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = text,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (activeSort == sortKey) {
                Spacer(modifier = Modifier.width(2.dp))
                Icon(
                    imageVector = if (isAsc) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = "Sort",
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}

@Composable
fun CellText(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight = FontWeight.Normal,
    alignment: Alignment = Alignment.CenterStart,
    isMono: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(width)
            .clip(RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 8.dp),
        contentAlignment = alignment
    ) {
        Text(
            text = text,
            color = if (color != Color.Unspecified) color else MaterialTheme.colorScheme.onSurface,
            fontWeight = fontWeight,
            fontSize = 12.sp,
            fontFamily = if (isMono) FontFamily.Monospace else FontFamily.Default,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
