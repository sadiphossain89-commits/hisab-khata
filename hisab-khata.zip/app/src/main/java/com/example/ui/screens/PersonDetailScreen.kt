package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PersonEntity
import com.example.data.model.PersonType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.NumberFormatHelper
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.NegativeRed
import com.example.ui.theme.NegativeRedContainer
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.PositiveGreenContainer
import com.example.ui.viewmodel.AccountingUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonDetailScreen(
    personId: Long,
    uiState: AccountingUiState,
    onBack: () -> Unit,
    onEditPerson: (PersonEntity) -> Unit,
    onDeletePerson: (Long) -> Unit,
    onAddTransactionForPerson: (TransactionType, Long, String) -> Unit,
    onTransactionClick: (TransactionEntity) -> Unit,
    onTransactionDelete: (TransactionEntity) -> Unit,
    onGetStatementText: (Long) -> String
) {
    val context = LocalContext.current
    val personSummary = uiState.personsWithSummary.find { it.person.id == personId }
    val isBn = uiState.isBengali
    val currency = uiState.activeBusiness?.currencySymbol ?: "৳"

    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (personSummary == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(if (isBn) "ব্যক্তি পাওয়া যায়নি" else "Person not found")
        }
        return
    }

    val person = personSummary.person
    val balance = personSummary.currentBalance
    val personTransactions = uiState.allTransactions.filter { it.personId == personId }

    if (showDeleteConfirm) {
        DeleteConfirmDialog(
            title = if (isBn) "ব্যক্তি মুছে ফেলবেন?" else "Delete Person?",
            message = if (isBn) "${person.name}-এর সকল হিসাব মুছে ফেলা হবে। আপনি কি নিশ্চিত?"
            else "All transactions for ${person.name} will be permanently removed.",
            isBengali = isBn,
            onConfirm = {
                onDeletePerson(person.id)
                onBack()
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(person.name, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("person_detail_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { onEditPerson(person) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = NegativeRed)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // 1. Balance Summary Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (balance > 0) PositiveGreenContainer else if (balance < 0) NegativeRedContainer else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (balance > 0) {
                                if (isBn) "বর্তমান বাকি / পাওনা (Due to Receive)" else "Current Due Receivable"
                            } else if (balance < 0) {
                                if (isBn) "বর্তমান দেনা (Payable to Person)" else "Current Payable Due"
                            } else {
                                if (isBn) "হিসাব সম্পূর্ণ শোধ (Zero Balance)" else "Settled Account"
                            },
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = if (balance > 0) PositiveGreen else if (balance < 0) NegativeRed else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = NumberFormatHelper.formatMoney(kotlin.math.abs(balance), currency, isBn),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 28.sp,
                                color = if (balance > 0) PositiveGreen else if (balance < 0) NegativeRed else MaterialTheme.colorScheme.onSurface
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = if (isBn) "মোট পাওনা (+)" else "Total Debit (+)", fontSize = 11.sp)
                                Text(
                                    text = NumberFormatHelper.formatMoney(personSummary.totalDebit, currency, isBn),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = PositiveGreen
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = if (isBn) "মোট দেনা/জমা (-)" else "Total Credit (-)", fontSize = 11.sp)
                                Text(
                                    text = NumberFormatHelper.formatMoney(personSummary.totalCredit, currency, isBn),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = NegativeRed
                                )
                            }
                        }
                    }
                }
            }

            // 2. Action Buttons (Call, SMS, Statement Share)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (person.phone.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${person.phone}"))
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp), tint = EmeraldPrimary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = if (isBn) "কল" else "Call", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                try {
                                    val statement = onGetStatementText(person.id)
                                    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${person.phone}")).apply {
                                        putExtra("sms_body", statement)
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(16.dp), tint = InfoBlue)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = if (isBn) "এসএমএস" else "SMS", fontSize = 12.sp)
                        }
                    }

                    ElevatedButton(
                        onClick = {
                            val statement = onGetStatementText(person.id)
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, statement)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, if (isBn) "স্টেটমেন্ট শেয়ার করুন" else "Share Statement"))
                        },
                        modifier = Modifier.weight(1.3f),
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = EmeraldPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (isBn) "স্টেটমেন্ট পাঠান" else "Share Slip", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 3. Quick Ledger Entries for this person
            item {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onAddTransactionForPerson(TransactionType.DUE_GIVEN, person.id, person.name) },
                        colors = ButtonDefaults.buttonColors(containerColor = PositiveGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isBn) "+ পাওনা (বাকি)" else "+ Due Given", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onAddTransactionForPerson(TransactionType.RECEIVED, person.id, person.name) },
                        colors = ButtonDefaults.buttonColors(containerColor = InfoBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isBn) "+ টাকা জমা" else "+ Money In", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onAddTransactionForPerson(TransactionType.DUE_TAKEN, person.id, person.name) },
                        colors = ButtonDefaults.buttonColors(containerColor = NegativeRed),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isBn) "+ দেনা" else "+ Due Taken", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 4. Ledger History Header
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = (if (isBn) "লেনদেনের খাতা (" else "Ledger History (") +
                            NumberFormatHelper.formatNumber(personTransactions.size, isBn) + ")",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            // 5. Transactions List
            if (personTransactions.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isBn) "এই ব্যক্তির সাথে এখনো কোনো লেনদেন নেই।" else "No transactions for this person yet.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            } else {
                items(personTransactions, key = { it.id }) { txn ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        TransactionRowItem(
                            transaction = txn,
                            currencySymbol = currency,
                            isBengali = isBn,
                            onClick = { onTransactionClick(txn) },
                            onEdit = { onTransactionClick(txn) },
                            onDelete = { onTransactionDelete(txn) }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}
