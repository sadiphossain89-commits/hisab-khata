package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PersonEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.AddExpenseDialog
import com.example.ui.components.AddPersonDialog
import com.example.ui.components.AddSalePurchaseDialog
import com.example.ui.components.AddTransactionDialog
import com.example.ui.components.AppBottomBar
import com.example.ui.components.AppTopBar
import com.example.ui.components.BackupRestoreDialog
import com.example.ui.components.CreateBusinessDialog
import com.example.ui.components.SecurityPinDialog
import com.example.ui.screens.AccountsScreen
import com.example.ui.screens.ExpenseScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PersonDetailScreen
import com.example.ui.screens.PinLockScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SpreadsheetScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AccountingViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: AccountingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                HisabKhataApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun HisabKhataApp(viewModel: AccountingViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    // Dialog state variables
    var showAddTransactionDialog by remember { mutableStateOf(false) }
    var transactionDialogType by remember { mutableStateOf(TransactionType.SALE) }
    var transactionDialogPersonId by remember { mutableStateOf<Long?>(null) }

    var showAddPersonDialog by remember { mutableStateOf(false) }
    var editingPerson by remember { mutableStateOf<PersonEntity?>(null) }

    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showAddSalePurchaseDialog by remember { mutableStateOf(false) }
    var salePurchaseDialogType by remember { mutableStateOf("SALE") }

    var showCreateBusinessDialog by remember { mutableStateOf(false) }
    var showSecurityPinDialog by remember { mutableStateOf(false) }
    var showBackupRestoreDialog by remember { mutableStateOf(false) }

    // Handle user notification messages
    LaunchedEffect(uiState.userMessage) {
        uiState.userMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUserMessage()
        }
    }

    // Check PIN Lock state
    if (uiState.isPinLocked) {
        PinLockScreen(
            isBengali = uiState.isBengali,
            onUnlock = { pin -> viewModel.unlockWithPin(pin) }
        )
        return
    }

    // Dialogs
    if (showAddTransactionDialog && uiState.activeBusiness != null) {
        AddTransactionDialog(
            initialType = transactionDialogType,
            initialPersonId = transactionDialogPersonId,
            persons = uiState.personsWithSummary.map { it.person },
            isBengali = uiState.isBengali,
            onDismiss = {
                showAddTransactionDialog = false
                transactionDialogPersonId = null
            },
            onSave = { personId, personName, type, amount, date, description, paymentMethod, reference, note ->
                viewModel.saveTransaction(
                    personId = personId,
                    personName = personName,
                    type = type,
                    amount = amount,
                    date = date,
                    description = description,
                    paymentMethod = paymentMethod,
                    reference = reference,
                    note = note
                )
            }
        )
    }

    if (showAddPersonDialog && uiState.activeBusiness != null) {
        AddPersonDialog(
            initialPerson = editingPerson,
            businessId = uiState.activeBusiness!!.id,
            isBengali = uiState.isBengali,
            onDismiss = {
                showAddPersonDialog = false
                editingPerson = null
            },
            onSave = { person ->
                viewModel.savePerson(person)
            }
        )
    }

    if (showAddExpenseDialog && uiState.activeBusiness != null) {
        AddExpenseDialog(
            businessId = uiState.activeBusiness!!.id,
            isBengali = uiState.isBengali,
            onDismiss = { showAddExpenseDialog = false },
            onSave = { expense ->
                viewModel.saveExpense(expense)
            }
        )
    }

    if (showAddSalePurchaseDialog && uiState.activeBusiness != null) {
        AddSalePurchaseDialog(
            type = salePurchaseDialogType,
            businessId = uiState.activeBusiness!!.id,
            persons = uiState.personsWithSummary.map { it.person },
            isBengali = uiState.isBengali,
            onDismiss = { showAddSalePurchaseDialog = false },
            onSave = { item ->
                viewModel.saveSalePurchase(item)
            }
        )
    }

    if (showCreateBusinessDialog) {
        CreateBusinessDialog(
            isBengali = uiState.isBengali,
            onDismiss = { showCreateBusinessDialog = false },
            onCreate = { name, owner, phone, address, currency ->
                viewModel.createNewBusiness(name, owner, phone, address, currency)
            }
        )
    }

    if (showSecurityPinDialog) {
        SecurityPinDialog(
            isPinEnabled = uiState.hasPinSet,
            isBengali = uiState.isBengali,
            onDismiss = { showSecurityPinDialog = false },
            onSave = { enabled, pin ->
                viewModel.updatePinSecurity(enabled, pin)
            }
        )
    }

    if (showBackupRestoreDialog) {
        BackupRestoreDialog(
            isBengali = uiState.isBengali,
            onDismiss = { showBackupRestoreDialog = false },
            onExportJson = {
                // Triggered in repository
            },
            onRestoreJson = { json ->
                viewModel.restoreBackup(json)
            }
        )
    }

    Scaffold(
        topBar = {
            if (uiState.selectedPersonIdForDetail == null) {
                AppTopBar(
                    activeBusiness = uiState.activeBusiness,
                    allBusinesses = uiState.allBusinesses,
                    isBengali = uiState.isBengali,
                    onSwitchBusiness = { viewModel.switchBusiness(it) },
                    onCreateNewBusiness = { showCreateBusinessDialog = true },
                    onToggleLanguage = { viewModel.toggleLanguage() },
                    onOpenSecuritySettings = { showSecurityPinDialog = true }
                )
            }
        },
        bottomBar = {
            if (uiState.selectedPersonIdForDetail == null) {
                AppBottomBar(
                    selectedTab = uiState.selectedTab,
                    isBengali = uiState.isBengali,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Check if Individual Person Details screen is open
            if (uiState.selectedPersonIdForDetail != null) {
                PersonDetailScreen(
                    personId = uiState.selectedPersonIdForDetail!!,
                    uiState = uiState,
                    onBack = { viewModel.selectPersonDetail(null) },
                    onEditPerson = { person ->
                        editingPerson = person
                        showAddPersonDialog = true
                    },
                    onDeletePerson = { id -> viewModel.deletePerson(id) },
                    onAddTransactionForPerson = { type, personId, personName ->
                        transactionDialogType = type
                        transactionDialogPersonId = personId
                        showAddTransactionDialog = true
                    },
                    onTransactionClick = { txn ->
                        transactionDialogType = try {
                            TransactionType.valueOf(txn.type)
                        } catch (e: Exception) {
                            TransactionType.SALE
                        }
                        transactionDialogPersonId = txn.personId
                        showAddTransactionDialog = true
                    },
                    onTransactionDelete = { txn -> viewModel.deleteTransaction(txn) },
                    onGetStatementText = { id -> viewModel.getPersonStatementText(id) }
                )
            } else {
                // 5 Main Tabs
                when (uiState.selectedTab) {
                    0 -> HomeScreen(
                        uiState = uiState,
                        onNavigateToTab = { viewModel.selectTab(it) },
                        onOpenAddTransaction = { type ->
                            transactionDialogType = type
                            transactionDialogPersonId = null
                            showAddTransactionDialog = true
                        },
                        onOpenAddPerson = {
                            editingPerson = null
                            showAddPersonDialog = true
                        },
                        onOpenAddExpense = { showAddExpenseDialog = true },
                        onOpenAddSale = {
                            salePurchaseDialogType = "SALE"
                            showAddSalePurchaseDialog = true
                        },
                        onOpenAddPurchase = {
                            salePurchaseDialogType = "PURCHASE"
                            showAddSalePurchaseDialog = true
                        },
                        onTransactionClick = { txn ->
                            transactionDialogType = try {
                                TransactionType.valueOf(txn.type)
                            } catch (e: Exception) {
                                TransactionType.SALE
                            }
                            transactionDialogPersonId = txn.personId
                            showAddTransactionDialog = true
                        },
                        onTransactionDelete = { txn -> viewModel.deleteTransaction(txn) }
                    )
                    1 -> AccountsScreen(
                        uiState = uiState,
                        onSearchChange = { viewModel.setSearchQuery(it) },
                        onFilterChange = { viewModel.setAccountsFilter(it) },
                        onSelectPerson = { viewModel.selectPersonDetail(it) },
                        onAddNewPerson = {
                            editingPerson = null
                            showAddPersonDialog = true
                        }
                    )
                    2 -> SpreadsheetScreen(
                        uiState = uiState,
                        onSearchChange = { viewModel.setSearchQuery(it) },
                        onDateFilterChange = { viewModel.setDateFilter(it) },
                        onSortColumn = { viewModel.setSpreadsheetSorting(it) },
                        onUpdateCell = { txn, field, value ->
                            viewModel.updateSpreadsheetCell(txn, field, value)
                        },
                        onAddNewTransaction = {
                            transactionDialogType = TransactionType.SALE
                            transactionDialogPersonId = null
                            showAddTransactionDialog = true
                        },
                        onDuplicateTransaction = { viewModel.duplicateTransaction(it) },
                        onDeleteTransaction = { viewModel.deleteTransaction(it) },
                        onUndo = { viewModel.undoLastDeletion() },
                        onExportCsv = { viewModel.getExportCsvData() }
                    )
                    3 -> ExpenseScreen(
                        uiState = uiState,
                        onCategoryFilterChange = { viewModel.setExpenseCategoryFilter(it) },
                        onAddNewExpense = { showAddExpenseDialog = true },
                        onDeleteExpense = { viewModel.deleteExpense(it) }
                    )
                    4 -> ReportsScreen(
                        uiState = uiState,
                        onToggleLanguage = { viewModel.toggleLanguage() },
                        onOpenSecurityPin = { showSecurityPinDialog = true },
                        onOpenBackupRestore = { showBackupRestoreDialog = true },
                        onExportCsv = { viewModel.getExportCsvData() }
                    )
                }
            }
        }
    }
}
