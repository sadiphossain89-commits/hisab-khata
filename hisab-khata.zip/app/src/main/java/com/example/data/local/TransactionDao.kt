package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE businessId = :businessId ORDER BY date DESC, id DESC")
    fun getTransactionsByBusiness(businessId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE businessId = :businessId ORDER BY date ASC, id ASC")
    fun getTransactionsByBusinessAsc(businessId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE businessId = :businessId AND personId = :personId ORDER BY date DESC, id DESC")
    fun getTransactionsByPerson(businessId: Long, personId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE businessId = :businessId AND date >= :startDate AND date <= :endDate ORDER BY date DESC")
    fun getTransactionsByDateRange(businessId: Long, startDate: Long, endDate: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getTransactionById(id: Long): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transactions: List<TransactionEntity>)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)

    @Query("DELETE FROM transactions WHERE personId = :personId")
    suspend fun deleteTransactionsByPersonId(personId: Long)

    @Query("SELECT * FROM transactions WHERE businessId = :businessId")
    suspend fun getAllTransactionsList(businessId: Long): List<TransactionEntity>
}
