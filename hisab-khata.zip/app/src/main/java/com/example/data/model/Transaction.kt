package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "transactions",
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["personId"]),
        Index(value = ["date"])
    ]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val personId: Long? = null,
    val personName: String = "",
    val type: String = TransactionType.SALE.name,
    val amount: Double = 0.0,
    val date: Long = System.currentTimeMillis(),
    val description: String = "",
    val paymentMethod: String = PaymentMethod.CASH.name,
    val referenceNumber: String = "",
    val note: String = "",
    val debit: Double = 0.0,  // পাওনা / বিক্রয় / গ্রাহকের বাকি বৃদ্ধি
    val credit: Double = 0.0, // দেনা / ক্রয় / প্রাপ্ত টাকা / সমন্বয়
    val runningBalance: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
