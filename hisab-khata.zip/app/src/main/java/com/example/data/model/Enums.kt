package com.example.data.model

enum class PersonType(val bn: String, val en: String) {
    CUSTOMER("কাস্টমার", "Customer"),
    SUPPLIER("সাপ্লায়ার / মহাজন", "Supplier"),
    EMPLOYEE("কর্মচারী", "Employee"),
    OTHER("অন্যান্য", "Other");

    fun label(isBn: Boolean): String = if (isBn) bn else en
}

enum class TransactionType(
    val bn: String,
    val en: String,
    val isPositiveForCustomer: Boolean, // increases customer balance / they owe us
    val isIncome: Boolean,
    val isExpense: Boolean
) {
    DUE_GIVEN("বাকি দেওয়া (পাওনা)", "Given Credit (Receivable)", true, false, false),
    DUE_TAKEN("বাকি নেওয়া (দেনা)", "Taken Credit (Payable)", false, false, false),
    RECEIVED("টাকা জমা / গ্রহণ", "Received Money", false, true, false),
    PAID("টাকা পরিশোধ / ফেরত", "Paid / Return", true, false, true),
    SALE("পণ্য বিক্রয়", "Product Sale", true, true, false),
    PURCHASE("পণ্য ক্রয়", "Product Purchase", false, false, true),
    EXPENSE("ব্যবসার খরচ", "Business Expense", false, false, true),
    INCOME("অন্যান্য আয়", "Other Income", false, true, false);

    fun label(isBn: Boolean): String = if (isBn) bn else en
}

enum class PaymentMethod(val bn: String, val en: String) {
    CASH("নগদ (Cash)", "Cash"),
    BKASH("বিকাশ (bKash)", "bKash"),
    NAGAD("নগদ (Nagad)", "Nagad"),
    ROCKET("রকেট (Rocket)", "Rocket"),
    BANK("ব্যাংক ট্রান্সফার", "Bank Transfer"),
    CHEQUE("চেক (Cheque)", "Cheque"),
    OTHER("অন্যান্য", "Other");

    fun label(isBn: Boolean): String = if (isBn) bn else en
}

enum class ExpenseCategory(val bn: String, val en: String) {
    SHOP_RENT("দোকান ভাড়া", "Shop Rent"),
    SALARY("কর্মচারী বেতন", "Employee Salary"),
    TRANSPORT("পরিবহন ও যাতায়াত", "Transport"),
    ELECTRICITY("বিদ্যুৎ বিল", "Electricity"),
    WATER("পানি বিল", "Water Bill"),
    INTERNET("ইন্টারনেট বিল", "Internet"),
    MOBILE("মোবাইল রিচার্জ", "Mobile Bill"),
    GOODS_PURCHASE("মালামাল ক্রয়", "Goods/Supplies"),
    FOOD("খাবার ও নাস্তা", "Food & Snacks"),
    ENTERTAINMENT("আপ্যায়ন", "Entertainment"),
    MAINTENANCE("মেরামত ও রক্ষণাবেক্ষণ", "Maintenance"),
    OTHER("অন্যান্য খরচ", "Other Expense");

    fun label(isBn: Boolean): String = if (isBn) bn else en
}

enum class DateRangeFilter(val bn: String, val en: String) {
    ALL("সকল সময়", "All Time"),
    TODAY("আজ", "Today"),
    YESTERDAY("গতকাল", "Yesterday"),
    THIS_WEEK("এই সপ্তাহ", "This Week"),
    THIS_MONTH("এই মাস", "This Month"),
    LAST_MONTH("গত মাস", "Last Month"),
    CUSTOM("কাস্টম তারিখ", "Custom Range");

    fun label(isBn: Boolean): String = if (isBn) bn else en
}
