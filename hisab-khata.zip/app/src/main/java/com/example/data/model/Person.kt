package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "persons")
data class PersonEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val personType: String = PersonType.CUSTOMER.name,
    val openingBalance: Double = 0.0,
    val openingBalanceType: String = "RECEIVABLE", // RECEIVABLE (পাওনা), PAYABLE (দেনা)
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class PersonWithSummary(
    val person: PersonEntity,
    val totalDebit: Double = 0.0,   // পাওনা / বিক্রয় / দেওয়া বাকি
    val totalCredit: Double = 0.0,  // দেনা / ক্রয় / জমা দেওয়া
    val totalReceived: Double = 0.0, // টাকা জমা
    val currentBalance: Double = 0.0, // Positive: তারা আমাদের দেবে (পাওনা), Negative: আমরা দেবো (দেনা)
    val transactionCount: Int = 0,
    val lastTransactionDate: Long? = null
)
