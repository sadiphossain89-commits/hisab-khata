package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.BusinessEntity
import com.example.data.model.ExpenseCategory
import com.example.data.model.ExpenseEntity
import com.example.data.model.PaymentMethod
import com.example.data.model.PersonEntity
import com.example.data.model.PersonType
import com.example.data.model.PersonWithSummary
import com.example.data.model.SalePurchaseEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AccountingRepository(private val database: AppDatabase) {
    private val businessDao = database.businessDao()
    private val personDao = database.personDao()
    private val transactionDao = database.transactionDao()
    private val expenseDao = database.expenseDao()
    private val salePurchaseDao = database.salePurchaseDao()

    // Businesses
    fun getAllBusinesses(): Flow<List<BusinessEntity>> = businessDao.getAllBusinesses()
    suspend fun getBusinessById(id: Long) = businessDao.getBusinessById(id)
    suspend fun insertBusiness(business: BusinessEntity): Long = businessDao.insertBusiness(business)
    suspend fun updateBusiness(business: BusinessEntity) = businessDao.updateBusiness(business)
    suspend fun deleteBusiness(id: Long) = businessDao.deleteBusinessById(id)

    // Persons
    fun getPersonsByBusiness(businessId: Long): Flow<List<PersonEntity>> =
        personDao.getPersonsByBusiness(businessId)
    suspend fun getPersonById(id: Long) = personDao.getPersonById(id)
    suspend fun insertPerson(person: PersonEntity): Long = personDao.insertPerson(person)
    suspend fun updatePerson(person: PersonEntity) = personDao.updatePerson(person)
    suspend fun deletePerson(id: Long) {
        transactionDao.deleteTransactionsByPersonId(id)
        personDao.deletePersonById(id)
    }

    // Transactions
    fun getTransactionsByBusiness(businessId: Long): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsByBusiness(businessId)

    fun getTransactionsByPerson(businessId: Long, personId: Long): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsByPerson(businessId, personId)

    suspend fun insertTransaction(transaction: TransactionEntity): Long =
        transactionDao.insertTransaction(transaction)

    suspend fun updateTransaction(transaction: TransactionEntity) =
        transactionDao.updateTransaction(transaction)

    suspend fun deleteTransaction(id: Long) = transactionDao.deleteTransactionById(id)

    // Expenses
    fun getExpensesByBusiness(businessId: Long): Flow<List<ExpenseEntity>> =
        expenseDao.getExpensesByBusiness(businessId)

    suspend fun insertExpense(expense: ExpenseEntity): Long {
        val id = expenseDao.insertExpense(expense)
        // Also register as a general transaction in the main ledger
        val txn = TransactionEntity(
            businessId = expense.businessId,
            personId = null,
            personName = expense.category,
            type = TransactionType.EXPENSE.name,
            amount = expense.amount,
            date = expense.date,
            description = expense.description.ifBlank { expense.category },
            paymentMethod = expense.paymentMethod,
            note = expense.note,
            debit = 0.0,
            credit = expense.amount
        )
        transactionDao.insertTransaction(txn)
        return id
    }

    suspend fun updateExpense(expense: ExpenseEntity) = expenseDao.updateExpense(expense)
    suspend fun deleteExpense(id: Long) = expenseDao.deleteExpenseById(id)

    // Sales & Purchases
    fun getSalePurchaseItems(businessId: Long): Flow<List<SalePurchaseEntity>> =
        salePurchaseDao.getItemsByBusiness(businessId)

    suspend fun insertSalePurchase(item: SalePurchaseEntity): Long {
        val id = salePurchaseDao.insertItem(item)
        // Also create a linked ledger transaction
        val txnType = if (item.type == "SALE") TransactionType.SALE.name else TransactionType.PURCHASE.name
        val debit = if (item.type == "SALE") item.totalAmount else item.paidAmount
        val credit = if (item.type == "SALE") item.paidAmount else item.totalAmount

        val txn = TransactionEntity(
            businessId = item.businessId,
            personId = item.personId,
            personName = item.personName,
            type = txnType,
            amount = item.totalAmount,
            date = item.date,
            description = "${item.productName} (পরিমাণ: ${item.quantity} x ${item.unitPrice})",
            note = "পরিশোধ: ৳${item.paidAmount}, বাকি: ৳${item.dueAmount}",
            debit = debit,
            credit = credit
        )
        transactionDao.insertTransaction(txn)
        return id
    }

    // Initialize Default Demo Data if DB is empty
    suspend fun seedInitialDataIfNeeded(): Long {
        val firstBiz = businessDao.getFirstBusiness()
        if (firstBiz != null) {
            return firstBiz.id
        }

        val bizId = businessDao.insertBusiness(
            BusinessEntity(
                name = "মেসার্স সততা ট্রেডার্স",
                ownerName = "মো: শরীফ মাতব্বর",
                phone = "01700000000",
                address = "চকবাজার, ঢাকা",
                currencySymbol = "৳",
                businessType = "পাইকারি ও খুচরা বিক্রয়"
            )
        )

        // Seed Customers & Suppliers
        val p1 = personDao.insertPerson(
            PersonEntity(
                businessId = bizId,
                name = "আব্দুর রহিম",
                phone = "01711223344",
                address = "ধানমন্ডি, ঢাকা",
                personType = PersonType.CUSTOMER.name,
                openingBalance = 5000.0,
                openingBalanceType = "RECEIVABLE",
                note = "নিয়মিত খুচরা কাস্টমার"
            )
        )

        val p2 = personDao.insertPerson(
            PersonEntity(
                businessId = bizId,
                name = "করিম ব্রাদার্স এন্ড সন্স",
                phone = "01819887766",
                address = "খাতুনগঞ্জ, চট্টগ্রাম",
                personType = PersonType.SUPPLIER.name,
                openingBalance = 12000.0,
                openingBalanceType = "PAYABLE",
                note = "প্রধান মালামাল সরবরাহকারী"
            )
        )

        val p3 = personDao.insertPerson(
            PersonEntity(
                businessId = bizId,
                name = "রাসেল আহমেদ",
                phone = "01912345678",
                address = "মিরপুর-১০, ঢাকা",
                personType = PersonType.CUSTOMER.name,
                openingBalance = 0.0,
                openingBalanceType = "RECEIVABLE",
                note = "নতুন গ্রাহক"
            )
        )

        val now = System.currentTimeMillis()
        val oneDay = 24 * 60 * 60 * 1000L

        // Initial Transactions
        transactionDao.insertTransaction(
            TransactionEntity(
                businessId = bizId,
                personId = p1,
                personName = "আব্দুর রহিম",
                type = TransactionType.SALE.name,
                amount = 8500.0,
                date = now - (oneDay * 2),
                description = "পণ্য বিক্রয় (চাল ও ডাল)",
                paymentMethod = PaymentMethod.CASH.name,
                debit = 8500.0,
                credit = 5000.0,
                note = "নগদ জমা ৫০০০৳, বাকি ৩৫০০৳"
            )
        )

        transactionDao.insertTransaction(
            TransactionEntity(
                businessId = bizId,
                personId = p1,
                personName = "আব্দুর রহিম",
                type = TransactionType.RECEIVED.name,
                amount = 3500.0,
                date = now - (oneDay * 1),
                description = "বাকি টাকা পরিশোধ",
                paymentMethod = PaymentMethod.BKASH.name,
                debit = 0.0,
                credit = 3500.0,
                note = "বিকাশ নম্বর থেকে প্রাপ্ত"
            )
        )

        transactionDao.insertTransaction(
            TransactionEntity(
                businessId = bizId,
                personId = p2,
                personName = "করিম ব্রাদার্স এন্ড সন্স",
                type = TransactionType.PURCHASE.name,
                amount = 25000.0,
                date = now - (oneDay * 3),
                description = "পাইকারি স্টক মালামাল ক্রয়",
                paymentMethod = PaymentMethod.BANK.name,
                debit = 15000.0,
                credit = 25000.0,
                note = "অগ্রিম প্রদান ১৫০০০৳"
            )
        )

        transactionDao.insertTransaction(
            TransactionEntity(
                businessId = bizId,
                personId = p3,
                personName = "রাসেল আহমেদ",
                type = TransactionType.DUE_GIVEN.name,
                amount = 4200.0,
                date = now,
                description = "বাকিতে মালামাল সরবরাহ",
                paymentMethod = PaymentMethod.CASH.name,
                debit = 4200.0,
                credit = 0.0,
                note = "আগামী সপ্তাহে দেওয়ার কথা"
            )
        )

        // Seed Expenses
        expenseDao.insertExpense(
            ExpenseEntity(
                businessId = bizId,
                category = ExpenseCategory.SHOP_RENT.name,
                amount = 12000.0,
                date = now - (oneDay * 4),
                description = "চলতি মাসের দোকান ভাড়া",
                paymentMethod = PaymentMethod.BANK.name
            )
        )

        expenseDao.insertExpense(
            ExpenseEntity(
                businessId = bizId,
                category = ExpenseCategory.ELECTRICITY.name,
                amount = 2350.0,
                date = now - (oneDay * 2),
                description = "বিদ্যুৎ বিল পরিশোধ",
                paymentMethod = PaymentMethod.BKASH.name
            )
        )

        expenseDao.insertExpense(
            ExpenseEntity(
                businessId = bizId,
                category = ExpenseCategory.TRANSPORT.name,
                amount = 1500.0,
                date = now - (oneDay * 1),
                description = "মালামাল পরিবহন খরচ",
                paymentMethod = PaymentMethod.CASH.name
            )
        )

        return bizId
    }

    // Export to Excel / CSV format
    suspend fun generateCsvData(businessId: Long, isBn: Boolean): String {
        val biz = businessDao.getBusinessById(businessId)
        val txns = transactionDao.getAllTransactionsList(businessId)
        val sdf = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault())

        val sb = StringBuilder()
        sb.append(if (isBn) "ব্যবসায়ের নাম," else "Business Name,").append("\"${biz?.name ?: ""}\"\n")
        sb.append(if (isBn) "রিপোর্ট তৈরির তারিখ," else "Generated Date,").append("\"${sdf.format(Date())}\"\n\n")

        if (isBn) {
            sb.append("আইডি,তারিখ,ব্যক্তির নাম,লেনদেনের ধরন,বিবরণ,দেনা/ক্রয়(৳),পাওনা/বিক্রয়(৳),টাকা জমা(৳),পেমেন্ট মাধ্যম,নোট\n")
        } else {
            sb.append("ID,Date,Person Name,Type,Description,Debit(৳),Credit(৳),Received(৳),Payment Method,Note\n")
        }

        for (t in txns) {
            val dateStr = sdf.format(Date(t.date))
            val typeStr = try {
                TransactionType.valueOf(t.type).label(isBn)
            } catch (e: Exception) {
                t.type
            }
            val payMethodStr = try {
                PaymentMethod.valueOf(t.paymentMethod).label(isBn)
            } catch (e: Exception) {
                t.paymentMethod
            }

            sb.append("${t.id},")
            sb.append("\"$dateStr\",")
            sb.append("\"${t.personName.replace("\"", "\"\"")}\",")
            sb.append("\"$typeStr\",")
            sb.append("\"${t.description.replace("\"", "\"\"")}\",")
            sb.append("${t.debit},")
            sb.append("${t.credit},")
            sb.append("${t.amount},")
            sb.append("\"$payMethodStr\",")
            sb.append("\"${t.note.replace("\"", "\"\"")}\"\n")
        }

        return sb.toString()
    }

    // Generate Person Statement Text for SMS / WhatsApp / Print
    fun generatePersonStatement(
        person: PersonEntity,
        transactions: List<TransactionEntity>,
        summary: PersonWithSummary,
        currencySymbol: String,
        isBn: Boolean
    ): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val sb = StringBuilder()
        if (isBn) {
            sb.append("📄 *হিসাব বিবরণী*\n")
            sb.append("গ্রাহক: ${person.name}\n")
            if (person.phone.isNotBlank()) sb.append("মোবাইল: ${person.phone}\n")
            if (person.address.isNotBlank()) sb.append("ঠিকানা: ${person.address}\n")
            sb.append("----------------------------\n")
            sb.append("মোট পাওনা: $currencySymbol${String.format(Locale.US, "%.2f", summary.totalDebit)}\n")
            sb.append("মোট জমা: $currencySymbol${String.format(Locale.US, "%.2f", summary.totalReceived)}\n")
            val balanceStr = if (summary.currentBalance >= 0) "বর্তমান বাকি পাওনা" else "বর্তমান দেনা"
            sb.append("⭐ $balanceStr: $currencySymbol${String.format(Locale.US, "%.2f", kotlin.math.abs(summary.currentBalance))}\n")
            sb.append("----------------------------\n")
            sb.append("সর্বশেষ লেনদেনসমূহ:\n")
        } else {
            sb.append("📄 *Account Statement*\n")
            sb.append("Name: ${person.name}\n")
            if (person.phone.isNotBlank()) sb.append("Phone: ${person.phone}\n")
            sb.append("----------------------------\n")
            sb.append("Total Receivable: $currencySymbol${String.format(Locale.US, "%.2f", summary.totalDebit)}\n")
            sb.append("Total Received: $currencySymbol${String.format(Locale.US, "%.2f", summary.totalReceived)}\n")
            val balanceStr = if (summary.currentBalance >= 0) "Current Due" else "Current Advance"
            sb.append("⭐ $balanceStr: $currencySymbol${String.format(Locale.US, "%.2f", kotlin.math.abs(summary.currentBalance))}\n")
            sb.append("----------------------------\n")
            sb.append("Recent Transactions:\n")
        }

        transactions.take(10).forEach { t ->
            val dateStr = sdf.format(Date(t.date))
            val amountStr = "$currencySymbol${String.format(Locale.US, "%.2f", t.amount)}"
            val typeLabel = try { TransactionType.valueOf(t.type).label(isBn) } catch (e: Exception) { t.type }
            sb.append("• $dateStr: $typeLabel - $amountStr (${t.description})\n")
        }
        sb.append("\nধন্যবাদ। সাথে থাকার জন্য কৃতজ্ঞতা।")
        return sb.toString()
    }

    // Full JSON Backup
    suspend fun createBackupJson(businessId: Long): String {
        val biz = businessDao.getBusinessById(businessId) ?: return "{}"
        val persons = personDao.getPersonsList(businessId)
        val transactions = transactionDao.getAllTransactionsList(businessId)
        val expenses = expenseDao.getAllExpensesList(businessId)
        val salePurchases = salePurchaseDao.getAllItemsList(businessId)

        val root = JSONObject()
        root.put("version", 1)
        root.put("timestamp", System.currentTimeMillis())

        val bizObj = JSONObject()
        bizObj.put("id", biz.id)
        bizObj.put("name", biz.name)
        bizObj.put("ownerName", biz.ownerName)
        bizObj.put("phone", biz.phone)
        bizObj.put("address", biz.address)
        bizObj.put("currencySymbol", biz.currencySymbol)
        bizObj.put("businessType", biz.businessType)
        root.put("business", bizObj)

        val personArr = JSONArray()
        for (p in persons) {
            val po = JSONObject()
            po.put("id", p.id)
            po.put("businessId", p.businessId)
            po.put("name", p.name)
            po.put("phone", p.phone)
            po.put("address", p.address)
            po.put("personType", p.personType)
            po.put("openingBalance", p.openingBalance)
            po.put("openingBalanceType", p.openingBalanceType)
            po.put("note", p.note)
            personArr.put(po)
        }
        root.put("persons", personArr)

        val txnArr = JSONArray()
        for (t in transactions) {
            val to = JSONObject()
            to.put("id", t.id)
            to.put("businessId", t.businessId)
            to.put("personId", t.personId ?: -1)
            to.put("personName", t.personName)
            to.put("type", t.type)
            to.put("amount", t.amount)
            to.put("date", t.date)
            to.put("description", t.description)
            to.put("paymentMethod", t.paymentMethod)
            to.put("referenceNumber", t.referenceNumber)
            to.put("note", t.note)
            to.put("debit", t.debit)
            to.put("credit", t.credit)
            txnArr.put(to)
        }
        root.put("transactions", txnArr)

        val expArr = JSONArray()
        for (e in expenses) {
            val eo = JSONObject()
            eo.put("id", e.id)
            eo.put("businessId", e.businessId)
            eo.put("category", e.category)
            eo.put("amount", e.amount)
            eo.put("date", e.date)
            eo.put("description", e.description)
            eo.put("paymentMethod", e.paymentMethod)
            eo.put("note", e.note)
            expArr.put(eo)
        }
        root.put("expenses", expArr)

        return root.toString(2)
    }

    // Restore Backup from JSON
    suspend fun restoreFromJson(jsonString: String): Boolean {
        try {
            val root = JSONObject(jsonString)
            val bizObj = root.getJSONObject("business")
            val newBiz = BusinessEntity(
                name = bizObj.optString("name", "পুনরুদ্ধারকৃত ব্যবসা"),
                ownerName = bizObj.optString("ownerName", ""),
                phone = bizObj.optString("phone", ""),
                address = bizObj.optString("address", ""),
                currencySymbol = bizObj.optString("currencySymbol", "৳"),
                businessType = bizObj.optString("businessType", "সাধারণ ব্যবসা")
            )
            val newBizId = businessDao.insertBusiness(newBiz)

            val personIdMap = mutableMapOf<Long, Long>()
            val personArr = root.optJSONArray("persons")
            if (personArr != null) {
                for (i in 0 until personArr.length()) {
                    val po = personArr.getJSONObject(i)
                    val oldId = po.optLong("id", -1L)
                    val p = PersonEntity(
                        businessId = newBizId,
                        name = po.optString("name", "নামহীন"),
                        phone = po.optString("phone", ""),
                        address = po.optString("address", ""),
                        personType = po.optString("personType", PersonType.CUSTOMER.name),
                        openingBalance = po.optDouble("openingBalance", 0.0),
                        openingBalanceType = po.optString("openingBalanceType", "RECEIVABLE"),
                        note = po.optString("note", "")
                    )
                    val insertedId = personDao.insertPerson(p)
                    if (oldId != -1L) {
                        personIdMap[oldId] = insertedId
                    }
                }
            }

            val txnArr = root.optJSONArray("transactions")
            if (txnArr != null) {
                val txnList = mutableListOf<TransactionEntity>()
                for (i in 0 until txnArr.length()) {
                    val to = txnArr.getJSONObject(i)
                    val oldPersonId = to.optLong("personId", -1L)
                    val newPersonId = if (oldPersonId > 0) personIdMap[oldPersonId] else null
                    val t = TransactionEntity(
                        businessId = newBizId,
                        personId = newPersonId,
                        personName = to.optString("personName", ""),
                        type = to.optString("type", TransactionType.SALE.name),
                        amount = to.optDouble("amount", 0.0),
                        date = to.optLong("date", System.currentTimeMillis()),
                        description = to.optString("description", ""),
                        paymentMethod = to.optString("paymentMethod", PaymentMethod.CASH.name),
                        referenceNumber = to.optString("referenceNumber", ""),
                        note = to.optString("note", ""),
                        debit = to.optDouble("debit", 0.0),
                        credit = to.optDouble("credit", 0.0)
                    )
                    txnList.add(t)
                }
                transactionDao.insertAll(txnList)
            }

            val expArr = root.optJSONArray("expenses")
            if (expArr != null) {
                val expList = mutableListOf<ExpenseEntity>()
                for (i in 0 until expArr.length()) {
                    val eo = expArr.getJSONObject(i)
                    val e = ExpenseEntity(
                        businessId = newBizId,
                        category = eo.optString("category", ExpenseCategory.OTHER.name),
                        amount = eo.optDouble("amount", 0.0),
                        date = eo.optLong("date", System.currentTimeMillis()),
                        description = eo.optString("description", ""),
                        paymentMethod = eo.optString("paymentMethod", PaymentMethod.CASH.name),
                        note = eo.optString("note", "")
                    )
                    expList.add(e)
                }
                expenseDao.insertAll(expList)
            }

            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }
}
