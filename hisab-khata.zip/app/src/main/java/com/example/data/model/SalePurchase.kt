package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "sale_purchase_items",
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["personId"]),
        Index(value = ["date"])
    ]
)
data class SalePurchaseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val personId: Long? = null,
    val personName: String = "",
    val type: String = "SALE", // SALE or PURCHASE
    val productName: String = "",
    val quantity: Double = 1.0,
    val unitPrice: Double = 0.0,
    val totalAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val date: Long = System.currentTimeMillis(),
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
