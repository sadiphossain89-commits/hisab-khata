package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("hisab_khata_prefs", Context.MODE_PRIVATE)

    var activeBusinessId: Long
        get() = prefs.getLong(KEY_ACTIVE_BUSINESS_ID, 0L)
        set(value) = prefs.edit().putLong(KEY_ACTIVE_BUSINESS_ID, value).apply()

    var isBengali: Boolean
        get() = prefs.getBoolean(KEY_IS_BENGALI, true)
        set(value) = prefs.edit().putBoolean(KEY_IS_BENGALI, value).apply()

    var isPinLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_PIN_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_PIN_ENABLED, value).apply()

    var pinCode: String
        get() = prefs.getString(KEY_PIN_CODE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_PIN_CODE, value).apply()

    var isDarkTheme: Boolean?
        get() {
            return if (prefs.contains(KEY_DARK_THEME)) {
                prefs.getBoolean(KEY_DARK_THEME, false)
            } else {
                null
            }
        }
        set(value) {
            if (value == null) {
                prefs.edit().remove(KEY_DARK_THEME).apply()
            } else {
                prefs.edit().putBoolean(KEY_DARK_THEME, value).apply()
            }
        }

    companion object {
        private const val KEY_ACTIVE_BUSINESS_ID = "active_business_id"
        private const val KEY_IS_BENGALI = "is_bengali"
        private const val KEY_PIN_ENABLED = "pin_enabled"
        private const val KEY_PIN_CODE = "pin_code"
        private const val KEY_DARK_THEME = "dark_theme"
    }
}
