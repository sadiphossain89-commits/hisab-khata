package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "expenses",
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["category"]),
        Index(value = ["date"])
    ]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val category: String = ExpenseCategory.OTHER.name,
    val amount: Double = 0.0,
    val date: Long = System.currentTimeMillis(),
    val description: String = "",
    val paymentMethod: String = PaymentMethod.CASH.name,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
