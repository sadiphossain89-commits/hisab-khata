package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.SalePurchaseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SalePurchaseDao {
    @Query("SELECT * FROM sale_purchase_items WHERE businessId = :businessId ORDER BY date DESC")
    fun getItemsByBusiness(businessId: Long): Flow<List<SalePurchaseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: SalePurchaseEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<SalePurchaseEntity>)

    @Update
    suspend fun updateItem(item: SalePurchaseEntity)

    @Query("DELETE FROM sale_purchase_items WHERE id = :id")
    suspend fun deleteItemById(id: Long)

    @Query("SELECT * FROM sale_purchase_items WHERE businessId = :businessId")
    suspend fun getAllItemsList(businessId: Long): List<SalePurchaseEntity>
}
