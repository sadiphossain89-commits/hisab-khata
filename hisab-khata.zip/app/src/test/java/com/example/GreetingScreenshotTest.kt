package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.components.DashboardSummarySection
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

    @get:Rule val composeTestRule = createComposeRule()

    @Test
    fun dashboard_summary_screenshot() {
        composeTestRule.setContent {
            MyApplicationTheme {
                DashboardSummarySection(
                    currencySymbol = "৳",
                    totalReceivable = 12500.0,
                    totalPayable = 4800.0,
                    todaySales = 8500.0,
                    todayPurchases = 3200.0,
                    todayExpenses = 650.0,
                    totalNetProfit = 4650.0,
                    cashInHand = 15400.0,
                    totalTransactionsCount = 28,
                    isBengali = true
                )
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/dashboard_summary.png")
    }
}
