package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ui.components.NumberFormatHelper
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("হিসাব খাতা", appName)
    }

    @Test
    fun `test Bengali number formatting`() {
        val bnNumber = NumberFormatHelper.toBengaliDigits("123450")
        assertEquals("১২৩৪৫০", bnNumber)

        val moneyBn = NumberFormatHelper.formatMoney(500.0, "৳", true)
        assertEquals("৳ ৫০০.০০", moneyBn)
    }
}
